
import json as _json
import gzip
import zlib
import socket
import ssl
import io
from urllib import request as _urlreq
from urllib.error import URLError, HTTPError
from urllib.parse import urlencode, urlparse
from http.cookiejar import CookieJar




class RequestException(IOError):
	pass


class HTTPException(RequestException):
	pass


class Timeout(RequestException):
	pass


class ConnectionError(RequestException):
	pass


class exceptions:
	RequestException = RequestException
	HTTPError = HTTPException
	Timeout = Timeout
	ConnectionError = ConnectionError




class _CaseInsensitiveDict(dict):

	def __init__(self, data=None):
		super().__init__()
		self._lower = {}
		if data:
			for k, v in (data.items() if hasattr(data, "items") else data):
				self[k] = v

	def __setitem__(self, key, value):
		super().__setitem__(key, value)
		self._lower[key.lower()] = key

	def __getitem__(self, key):
		real = self._lower.get(key.lower(), key)
		return super().__getitem__(real)

	def get(self, key, default=None):
		try:
			return self[key]
		except KeyError:
			return default

	def __contains__(self, key):
		return key.lower() in self._lower


class Response:
	def __init__(self, raw_bytes, status_code, headers, url):
		self._content = raw_bytes
		self.status_code = int(status_code)
		self.headers = _CaseInsensitiveDict(headers or {})
		self.url = url
		self._text = None

	@property
	def content(self):
		return self._content

	@property
	def text(self):
		if self._text is not None:
			return self._text

		charset = None
		ct = self.headers.get("content-type", "")
		if "charset=" in ct.lower():
			try:
				charset = ct.lower().split("charset=", 1)[1].split(";")[0].strip()
			except Exception:
				charset = None
		try:
			self._text = self._content.decode(charset or "utf-8", "replace")
		except (LookupError, TypeError):
			self._text = self._content.decode("utf-8", "replace")
		return self._text

	def json(self, **kwargs):
		return _json.loads(self.text, **kwargs)

	def raise_for_status(self):
		if 400 <= self.status_code < 600:
			raise HTTPException("HTTP %s for %s" % (self.status_code, self.url))




class Session:
	def __init__(self):
		self.headers = {}
		self.cookies = CookieJar()


		self._opener_verify = _urlreq.build_opener(
			_urlreq.HTTPCookieProcessor(self.cookies),
		)
		ctx = ssl.create_default_context()
		ctx.check_hostname = False
		ctx.verify_mode = ssl.CERT_NONE
		self._opener_noverify = _urlreq.build_opener(
			_urlreq.HTTPCookieProcessor(self.cookies),
			_urlreq.HTTPSHandler(context=ctx),
		)

	def close(self):
		pass



	@staticmethod
	def _encode_body(data, json_obj, headers):
		if json_obj is not None:
			body = _json.dumps(json_obj).encode("utf-8")
			headers.setdefault("Content-Type", "application/json")
			return body
		if data is None:
			return None
		if isinstance(data, (bytes, bytearray)):
			return bytes(data)
		if isinstance(data, str):
			return data.encode("utf-8")
		if isinstance(data, dict):
			headers.setdefault("Content-Type",
			                   "application/x-www-form-urlencoded")
			return urlencode(data).encode("utf-8")
		raise TypeError("Unsupported data type: %r" % type(data))

	@staticmethod
	def _decode_body(raw_bytes, response_headers):
		enc = (response_headers.get("Content-Encoding")
		       or response_headers.get("content-encoding") or "").lower()
		if not raw_bytes:
			return b""
		try:
			if "gzip" in enc:
				return gzip.decompress(raw_bytes)
			if "deflate" in enc:
				try:
					return zlib.decompress(raw_bytes)
				except zlib.error:
					return zlib.decompress(raw_bytes, -zlib.MAX_WBITS)
		except Exception:
			pass
		return raw_bytes



	def request(self, method, url, headers=None, params=None, data=None,
	            json=None, timeout=None, stream=False, allow_redirects=True,
	            verify=True, max_bytes=None, **_ignored):

		if params:
			qs = urlencode(params, doseq=True)
			sep = "&" if ("?" in url) else "?"
			url = url + sep + qs


		hdrs = dict(self.headers)
		if headers:
			for k, v in headers.items():
				hdrs[str(k)] = str(v)


		hdrs.setdefault("Accept-Encoding", "gzip, deflate")

		body = self._encode_body(data, json, hdrs)

		req = _urlreq.Request(url, data=body, method=method.upper())
		for k, v in hdrs.items():
			req.add_header(k, v)

		opener = self._opener_verify if verify else self._opener_noverify

		try:
			to = timeout if timeout is not None else socket._GLOBAL_DEFAULT_TIMEOUT
			resp = opener.open(req, timeout=to)
		except HTTPError as e:

			raw = e.read() if hasattr(e, "read") else b""
			resp_headers = dict(e.headers.items()) if e.headers else {}
			body_bytes = self._decode_body(raw, resp_headers)
			return Response(body_bytes, e.code, resp_headers, e.geturl())
		except (URLError, socket.timeout) as e:
			reason = getattr(e, "reason", e)
			if isinstance(reason, socket.timeout) or "timed out" in str(reason).lower():
				raise Timeout(str(reason))
			raise ConnectionError(str(reason))
		except Exception as e:
			raise RequestException(str(e))

		if max_bytes:
			raw = resp.read(int(max_bytes))
			try:
				resp.close()
			except Exception:
				pass
		else:
			raw = resp.read()
		final_url = resp.geturl()
		resp_headers = dict(resp.headers.items()) if resp.headers else {}


		body_bytes = self._decode_body(raw, resp_headers)
		return Response(body_bytes, resp.status, resp_headers, final_url)


	def get(self, url, **kw): return self.request("GET", url, **kw)
	def post(self, url, **kw): return self.request("POST", url, **kw)
	def head(self, url, **kw): return self.request("HEAD", url, **kw)



RequestException = RequestException

__streamhub_vendored__ = True
