
from streamhub.utils import request, log, quote, urlparse, base64, re, format_exc
import json as _json
import random as _random
import string as _string
import time as _time

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")


def _hdr(referer=None):
	h = {"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"}
	if referer:
		h["Referer"] = referer
	return h


def _hdr_qs(referer_origin):
	return "Referer=%s&User-Agent=%s" % (
		quote(referer_origin, safe=""), quote(UA, safe=""))


VOE_HOSTS = ("voe.sx", "voe-un", "voe-net", "voe-net", "voeun", "voeunblock",
             "voe-network", "cloudwindow")

DOOD_HOSTS = ("dood.", "doodstream", "d0000d", "d000d", "ds2play", "dooood",
              "doods.", "vidply", "playmogo", "dood.to", "dood.watch",
              "dood.so", "dood.la", "dood.ws", "dood.yt", "dood.re",
              "all3do", "do0od", "doodcdn", "dooodster")


def _rot13(s):
	out = []
	for c in s:
		o = ord(c)
		if 65 <= o <= 90:
			out.append(chr((o - 65 + 13) % 26 + 65))
		elif 97 <= o <= 122:
			out.append(chr((o - 97 + 13) % 26 + 97))
		else:
			out.append(c)
	return "".join(out)


def _voe_decode(raw):
	step = _rot13(raw)
	for junk in ["@$", "^^", "~@", "%?", "*~", "!!", "#&"]:
		step = step.replace(junk, "_")
	step = step.replace("_", "")
	b = base64.b64decode(step)
	shifted = bytes((x - 3) % 256 for x in b)
	rev = shifted[::-1]
	final = base64.b64decode(rev)
	return _json.loads(final)


def resolve_voe(url):
	try:
		r = request("GET", url, headers=_hdr("https://voe.sx/"),
		            timeout=8, retries=1, allow_redirects=True)
		html = r.text
		for _ in range(3):
			mred = re.search(r"window\.location\.href\s*=\s*'(https?://[^']+)'", html)
			if not mred or mred.group(1) in r.url:
				break
			r = request("GET", mred.group(1), headers=_hdr("https://voe.sx/"),
			            timeout=15, retries=2, allow_redirects=True)
			html = r.text
		m = re.search(
			r'<script type="application/json"[^>]*>\s*(\[.*?\]|".*?")\s*</script>',
			html, re.S)
		if m:
			raw = _json.loads(m.group(1))
			if isinstance(raw, list):
				raw = raw[0]
			data = _voe_decode(raw)
			direct = data.get("direct_access_url")
			hls = data.get("source")
			src = direct if (direct and ".mp4" in direct) else (hls or direct)
			if src:
				origin = "https://%s" % urlparse(r.url).netloc
				return src, _hdr_qs(origin + "/")
		mm = re.search(r"'hls'\s*:\s*'([^']+\.m3u8[^']*)'", html) \
			or re.search(r'"hls"\s*:\s*"([^"]+\.m3u8[^"]*)"', html) \
			or re.search(r"(https?://[^\s'\"<>]+\.m3u8[^\s'\"<>]*)", html)
		if mm:
			cand = mm.group(1)
			if "\\/" in cand:
				cand = cand.replace("\\/", "/")
			origin = "https://%s" % urlparse(r.url).netloc
			return cand, _hdr_qs(origin + "/")
	except Exception:
		log(format_exc())
	return None


def resolve_dood(url):
	try:
		r = request("GET", url, headers=_hdr("https://dood.to/"),
		            timeout=8, retries=1, allow_redirects=True)
		html = r.text
		final_host = "https://%s" % urlparse(r.url).netloc
		embed_ref = r.url
		m = re.search(r"(/pass_md5/[^'\"]+)", html)
		if not m:
			return None
		pass_path = m.group(1)
		tok = re.search(r"token=([a-z0-9]+)", html)
		token = tok.group(1) if tok else pass_path.rsplit("/", 1)[-1]
		pr = request("GET", final_host + pass_path,
		             headers=_hdr(embed_ref), timeout=8, retries=1)
		prefix = pr.text.strip()
		if not prefix.startswith("http"):
			return None
		rand = "".join(_random.choice(_string.ascii_letters + _string.digits)
		               for _ in range(10))
		expiry = int(_time.time() * 1000)
		final = "%s%s?token=%s&expiry=%d" % (prefix, rand, token, expiry)
		return final, _hdr_qs(final_host + "/")
	except Exception:
		log(format_exc())
	return None


_HLS_RE = re.compile(r'https?://[^\s\'"<>]+\.m3u8[^\s\'"<>]*')
_MP4_RE = re.compile(r'https?://[^\s\'"<>]+\.mp4[^\s\'"<>]*')
_ATOB_RE = re.compile(r"atob\(\s*[\"']([A-Za-z0-9+/=_-]{40,})[\"']\s*\)")


def resolve_generic(url, referer=None):
	try:
		r = request("GET", url, headers=_hdr(referer or url),
		            timeout=8, retries=1, allow_redirects=True)
		html = r.text
		origin = "https://%s" % urlparse(r.url).netloc
		for rx in (_HLS_RE, _MP4_RE):
			m = rx.search(html)
			if m:
				return m.group(0).replace("\\/", "/"), _hdr_qs(origin + "/")
		for blob in _ATOB_RE.findall(html):
			try:
				dec = base64.b64decode(blob + "==").decode("utf-8", "ignore")
			except Exception:
				continue
			for rx in (_HLS_RE, _MP4_RE):
				m = rx.search(dec)
				if m:
					return m.group(0), _hdr_qs(origin + "/")
	except Exception:
		log(format_exc())
	return None


def _match(url, hosts):
	low = url.lower()
	return any(h in low for h in hosts)


STREAMTAPE_HOSTS = ("streamtape", "stape", "strtape", "streamadblock",
                    "tapewithadblock", "streamta.pe", "tapeblocker",
                    "streamtapeadblock")

MIXDROP_HOSTS = ("mixdrop", "mxdrop", "mixdrp")

PACKED_HOSTS = ("supervideo", "filemoon", "moonmov", "vidoza", "vinovo",
                "streamruby", "rubystm", "vidmoly", "savefiles", "dropload",
                "highload", "redload", "streamvid", "veev", "vidsonic",
                "firestream", "flyfile", "vidara", "vidmatrix", "myvidplay",
                "upbolt", "clipwatching")

_PACKED_ARGS_RE = re.compile(
	r"\}\s*\(\s*'(.*?)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'(.*?)'\s*\.split\('\|'\)",
	re.S)

_SUB_RE = re.compile(r"\.substring\(\s*(\d+)\s*\)")
_LIT_RE = re.compile(
	r"""(['"])(.*?)\1\s*\)?((?:\s*\.substring\(\s*\d+\s*\))*)""")
_NOROBOT_RE = re.compile(
	r"ById\('norobotlink'\)\.innerHTML\s*=\s*([^;\n]+)")
_MIXDROP_RE = re.compile(r"""MDCore\.wurl\s*=\s*["']([^"']+)["']""")


def _b62(n, base):
	digits = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	if n < base:
		out = ""
	else:
		out = _b62(n // base, base)
	return out + digits[n % base]


def unpack(js):
	out = []
	for a in _PACKED_ARGS_RE.finditer(js or ""):
		try:
			payload = a.group(1)
			base, count = int(a.group(2)), int(a.group(3))
			words = a.group(4).split("|")
		except Exception:
			continue
		payload = (payload.replace("\\\\", "\\").replace("\\'", "'")
		           .replace('\\"', '"').replace("\\/", "/"))
		res = payload
		for i in range(count - 1, -1, -1):
			if i < len(words) and words[i]:
				res = re.sub(r"\b" + re.escape(_b62(i, base)) + r"\b",
				             words[i].replace("\\", "\\\\"), res)
		out.append(res)
	return "\n".join(out)


def _eval_concat(expr):
	out = []
	for _q, lit, subs in _LIT_RE.findall(expr):
		s = lit
		for n in _SUB_RE.findall(subs):
			s = s[int(n):]
		out.append(s)
	return "".join(out)


def resolve_streamtape(url):
	try:
		r = request("GET", url, headers=_hdr(url), timeout=8, retries=1)
		if r.status_code >= 400:
			return None
		m = _NOROBOT_RE.search(r.text)
		if not m:
			return None
		link = _eval_concat(m.group(1))
		if not link:
			return None
		if link.startswith("//"):
			link = "https:" + link
		elif link.startswith("/"):
			link = "https:/" + link
		if "get_video" not in link:
			return None
		origin = "https://%s" % urlparse(r.url).netloc
		return link, _hdr_qs(origin + "/")
	except Exception:
		log(format_exc())
	return None


def resolve_mixdrop(url):
	try:
		if "/f/" in url:
			url = url.replace("/f/", "/e/")
		r = request("GET", url, headers=_hdr(url), timeout=8, retries=1)
		if r.status_code >= 400:
			return None
		body = r.text
		m = _MIXDROP_RE.search(body) or _MIXDROP_RE.search(unpack(body))
		if not m:
			return None
		link = m.group(1)
		if link.startswith("//"):
			link = "https:" + link
		return link, _hdr_qs(r.url)
	except Exception:
		log(format_exc())
	return None


def resolve_packed(url, referer=None):
	for ref in (None, referer):
		try:
			r = request("GET", url, headers=_hdr(ref), timeout=8, retries=1)
			if r.status_code >= 400:
				continue
			origin = "https://%s" % urlparse(r.url).netloc
			for blob in (unpack(r.text), r.text):
				if not blob:
					continue
				for rx in (_HLS_RE, _MP4_RE):
					m = rx.search(blob)
					if m:
						return m.group(0).rstrip('"\\)\''), _hdr_qs(origin + "/")
		except Exception:
			log(format_exc())
	return None


def resolve(url, referer=None):
	if not url:
		return None
	if _match(url, VOE_HOSTS):
		res = resolve_voe(url)
		if res:
			return res
	if _match(url, DOOD_HOSTS):
		res = resolve_dood(url)
		if res:
			return res
	if _match(url, STREAMTAPE_HOSTS):
		res = resolve_streamtape(url)
		if res:
			return res
	if _match(url, MIXDROP_HOSTS):
		res = resolve_mixdrop(url)
		if res:
			return res
	if _match(url, PACKED_HOSTS):
		res = resolve_packed(url, referer)
		if res:
			return res
	return resolve_generic(url, referer)
