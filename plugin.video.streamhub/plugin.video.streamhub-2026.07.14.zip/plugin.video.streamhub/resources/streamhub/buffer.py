import os
import xml.etree.ElementTree as ET

from streamhub.utils import (getSetting, setSetting, log, dialog, format_exc,
                             translatePath)

PRESETS = {
	"0": None,
	"1": (50, 10),
	"2": (100, 20),
	"3": (250, 30),
}

_MB = 1024 * 1024


def _path():
	return os.path.join(translatePath("special://profile/"),
	                    "advancedsettings.xml")


def _indent(elem, level=0):
	pad = "\n" + "\t" * level
	if len(elem):
		if not (elem.text or "").strip():
			elem.text = pad + "\t"
		for child in elem:
			_indent(child, level + 1)
		if not (child.tail or "").strip():
			child.tail = pad
	if level and not (elem.tail or "").strip():
		elem.tail = pad


def current():
	p = _path()
	if not os.path.exists(p):
		return None
	try:
		root = ET.parse(p).getroot()
	except Exception:
		return None
	cache = root.find("cache")
	if cache is None:
		return None
	out = {}
	for key in ("memorysize", "readfactor", "buffermode"):
		node = cache.find(key)
		if node is not None and (node.text or "").strip():
			out[key] = (node.text or "").strip()
	return out or None


def apply(preset=None, announce=True):
	preset = preset if preset is not None else (getSetting("buffer_size") or "2")
	cfg = PRESETS.get(str(preset), PRESETS["2"])
	p = _path()

	if os.path.exists(p):
		try:
			tree = ET.parse(p)
			root = tree.getroot()
		except Exception:
			log("advancedsettings.xml unreadable, not touching it\n%s" % format_exc())
			return False
		if root.tag != "advancedsettings":
			log("advancedsettings.xml has unexpected root <%s>, skipping" % root.tag)
			return False
	else:
		root = ET.Element("advancedsettings")
		tree = ET.ElementTree(root)

	cache = root.find("cache")

	if cfg is None:
		if cache is None:
			return True
		root.remove(cache)
	else:
		mb, readfactor = cfg
		if cache is None:
			cache = ET.SubElement(root, "cache")
		for key, val in (("buffermode", "1"),
		                 ("memorysize", str(mb * _MB)),
		                 ("readfactor", str(readfactor))):
			node = cache.find(key)
			if node is None:
				node = ET.SubElement(cache, key)
			node.text = val

	if len(root) == 0 and os.path.exists(p):
		try:
			os.remove(p)
			return True
		except Exception:
			return False

	try:
		_indent(root)
		d = os.path.dirname(p)
		if d and not os.path.isdir(d):
			os.makedirs(d)
		tree.write(p, encoding="utf-8", xml_declaration=True)
		with open(p, "a", encoding="utf-8") as f:
			f.write("\n")
	except Exception:
		log("could not write advancedsettings.xml\n%s" % format_exc())
		return False

	log("buffer preset %s written to %s" % (preset, p))
	if announce:
		if cfg is None:
			msg = "Puffer deaktiviert - Kodi neu starten"
		else:
			msg = "Puffer: %d MB - Kodi neu starten" % cfg[0]
		dialog.notification("StreamHub", msg, time=6000)
	return True


def apply_if_changed():
	preset = str(getSetting("buffer_size") or "2")
	if preset == (getSetting("_buffer_applied") or ""):
		return False
	if apply(preset, announce=False):
		setSetting("_buffer_applied", preset)
		return True
	return False


def show_status():
	cur = current()
	preset = str(getSetting("buffer_size") or "2")
	cfg = PRESETS.get(preset)
	want = "aus" if cfg is None else "%d MB / readfactor %s" % cfg
	if not cur:
		live = "kein Cache konfiguriert (Kodi-Standard: 20 MB)"
	else:
		try:
			mb = int(cur.get("memorysize", "0")) // _MB
		except ValueError:
			mb = 0
		live = "%d MB / readfactor %s" % (mb, cur.get("readfactor", "?"))
	dialog.ok("StreamHub - Puffer",
	          "Eingestellt: %s\nIn advancedsettings.xml: %s\n\n"
	          "Änderungen wirken erst nach einem Kodi-Neustart." % (want, live))
