import json
import re

from html import unescape
from urllib.parse import quote

from lib.scrapers import register
from lib.scrapers.base import BaseScraper

_CARD_RE = re.compile(
	r'<a[^>]+href="(https?://ramoflix\.net/[^"/]+/)"[^>]*>\s*'
	r'<img[^>]*?(?:data-src="([^"]+)"[^>]*?)?alt="([^"]+)"',
	re.I)

_SERVERS_RE = re.compile(r'var\s+Servers\s*=\s*(\{.*?\})\s*;', re.S)

_SKIP_URL = ("/category/", "/genre/", "/cast/", "/director/", "/year/",
             "/tv-show", "/series", "/episode")
_SKIP_TITLE = ("staffel", "season", "episode", " s0")

_META_KEYS = {"post_id", "id", "imdb_id", "image", "vote_average", "site",
              "domain", "youtube_id", "autoembed", "premium"}

_SERVER_LABELS = {
	"embedru": "soap2night",
	"vidlink": "videasy",
	"superembed": "vidfast",
	"vidsrc": "vidking",
	"vidsrc2": "vidzee",
	"movieclub": "111movies",
	"svetacdn": "svetacdn",
	"openvids": "openvids",
}


@register
class RamoflixScraper(BaseScraper):
	name = "ramoflix"
	base_url = "https://ramoflix.net"
	language = "DE"
	media_types = ("movie",)
	enabled_setting = "ramoflix"

	def search(self, query, media_type="movie"):
		html = self.fetch_text(self.base_url + "/?s=" + quote(query))
		if not html:
			return []
		out, seen = [], set()
		for m in _CARD_RE.finditer(html):
			url, poster, title = m.group(1), m.group(2), unescape(m.group(3)).strip()
			if url in seen:
				continue
			seen.add(url)
			low = url.lower()
			if any(h in low for h in _SKIP_URL):
				continue
			if any(h in title.lower() for h in _SKIP_TITLE):
				continue
			out.append({"title": title, "year": None, "poster": poster,
			            "provider": self.name, "url": url})
			if len(out) >= 20:
				break
		return out

	def _servers(self, page_url):
		html = self.fetch_text(page_url)
		if not html:
			return {}
		m = _SERVERS_RE.search(html)
		if not m:
			return {}
		try:
			return json.loads(m.group(1))
		except Exception:
			return {}

	def get_details(self, item):
		data = self._servers(item.get("url"))
		return {"tmdb_id": data.get("id"), "imdb_id": data.get("imdb_id")}

	def get_sources(self, item):
		data = self._servers(item.get("url"))
		if not data:
			return []
		sources = []
		for key, val in data.items():
			if key in _META_KEYS or not isinstance(val, str):
				continue
			if not val.startswith("http"):
				continue
			label = _SERVER_LABELS.get(key, key)
			s = self.make_source(val, label="%s (ramoflix)" % label,
			                     referer=item.get("url"))
			if s:
				s["tmdb_id"] = data.get("id")
				s["imdb_id"] = data.get("imdb_id")
				sources.append(s)
		return sources
