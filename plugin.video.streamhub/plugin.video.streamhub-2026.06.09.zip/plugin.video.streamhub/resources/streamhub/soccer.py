
from streamhub.utils import *


def _humanize_event(ev):
	t = ev.get("time") or ""
	title = ev.get("title") or "?"
	cat = ev.get("category") or ""
	parts = [t, title]
	if cat and cat.lower() not in title.lower():
		parts.append("[%s]" % cat)
	return " - ".join(p for p in parts if p)


def index(params):
	from streamhub.dlhd import fetch_soccer_events
	try:
		events = fetch_soccer_events()
	except Exception:
		log(format_exc())
		events = []
	if not events:
		dialog.notification("StreamHub Soccer",
		                    "Keine Spiele gefunden (DLHD-Schedule leer oder nicht erreichbar)",
		                    time=4000)
		end()
		return
	set_content("videos")
	set_category("Live Soccer")


	by_day = {}
	for ev in events:
		by_day.setdefault(ev.get("day", "Today"), []).append(ev)

	if len(by_day) == 1:
		day = next(iter(by_day))
		_list_events(by_day[day])
	else:
		for day in by_day:
			label = "[B]%s[/B]  (%d Spiele)" % (day, len(by_day[day]))
			addDir2(label, "DefaultAddonPVRClient", "soccer_day", day=day)
		end()


def day(params):
	from streamhub.dlhd import fetch_soccer_events
	target = params.get("day", "")
	events = [e for e in fetch_soccer_events() if e.get("day", "") == target]
	set_content("videos")
	set_category("Live Soccer - %s" % target)
	_list_events(events)


def _list_events(events):
	for idx, ev in enumerate(events):
		ch_count = len(ev.get("channels", []))
		playable = any(c.get("playable") for c in ev.get("channels", []))
		label = _humanize_event(ev)
		if ch_count == 0:
			label = "[COLOR grey]%s  (no streams)[/COLOR]" % label
		elif not playable:
			label = "%s  [COLOR orange](only PPV/streamed — may not play)[/COLOR]" % label
		else:
			label = "%s  [COLOR green](%d streams)[/COLOR]" % (label, ch_count)

		o = ListItem(label)
		o.setArt({"icon": "DefaultAddonPVRClient.png"})
		o.setProperty("IsPlayable", "true")
		info_tag = ListItemInfoTag(o, 'video')
		info_tag.set_info({
			"title": ev.get("title", ""),
			"plot": "[B]%s %s[/B]\n%s\n\n%d Stream(s) verfügbar" % (
				ev.get("time", ""), ev.get("category", ""),
				ev.get("title", ""), ch_count
			),
		})
		params = {
			"action": "soccer_play",
			"event": json.dumps({
				"title": ev.get("title", ""),
				"time": ev.get("time", ""),
				"channels": ev.get("channels", []),
			}),
		}
		add(params, o, False)
	end()


def play(params):
	from streamhub.vjlive import resolve_link
	from streamhub.hosters import filter_alive
	try:
		ev = json.loads(params.get("event", "{}"))
	except Exception:
		showFailedNotification("Event-Daten ungültig")
		return
	channels = ev.get("channels", [])
	if not channels:
		showFailedNotification("Keine Streams für dieses Spiel")
		return


	playable_first = sorted(channels,
	                        key=lambda c: (0 if c.get("playable") else 1, c.get("label", "")))


	if getSetting("live_alive_check") == "true":
		probe_items = [{"url": c["url"], "_orig": c}
		               for c in playable_first if c.get("playable")]
		if probe_items:
			alive = {id(p["_orig"]) for p in filter_alive(probe_items, timeout=5)}
			playable_first = [c for c in playable_first
			                  if not c.get("playable") or id(c) in alive]

	labels = []
	for c in playable_first:
		tag = c.get("label", "Stream")
		if c.get("playable"):
			labels.append("✓ %s" % tag)
		else:
			labels.append("⚠ %s (best-effort)" % tag)

	idx = selectDialog(labels, "Stream wählen — %s" % ev.get("title", ""))
	if idx < 0:
		return
	chosen = playable_first[idx]

	url, headers = resolve_link(chosen["url"])
	if not url:
		showFailedNotification("Stream nicht abrufbar (%s)" % chosen.get("label", "?"))
		return


	o = ListItem(ev.get("title", "Soccer"))
	if "m3u8" in url or "hls" in url:
		inputstream = ("inputstream.ffmpegdirect"
		               if getSetting("hlsinputstream") == "0"
		               else "inputstream.adaptive")
	else:
		inputstream = "inputstream.ffmpegdirect"
	o.setProperty("inputstream", inputstream)
	if inputstream == "inputstream.ffmpegdirect":
		o.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
		o.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
		o.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
		o.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
		o.setProperty('inputstream.ffmpegdirect.protocol_whitelist',
		              'http,https,tcp,tls,crypto')
		stream_opts = ':'.join(['http_persistent=1', 'multiple_requests=1',
		                        'reconnect=1', 'reconnect_streamed=1',
		                        'reconnect_delay_max=2', 'timeout=10000000'])
		o.setProperty('inputstream.ffmpegdirect.stream_opts', stream_opts)
		o.setProperty('inputstream.ffmpegdirect.user_agent', 'libmpv')
	else:
		o.setProperty('inputstream.adaptive.manifest_type', 'hls')
		o.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')
		o.setProperty('inputstream.adaptive.config', '{"ssl_verify_peer":false}')
	if headers:
		if inputstream == "inputstream.adaptive":
			o.setProperty(f'{inputstream}.common_headers', headers)
			o.setProperty(f'{inputstream}.stream_headers', headers)
		else:
			url += f"|{headers}"
	o.setPath(url)
	o.setProperty("IsPlayable", "true")
	info_tag = ListItemInfoTag(o, 'video')
	info_tag.set_info({
		"title": ev.get("title", ""),
		"plot": "[B]%s[/B]\n%s" % (ev.get("title", ""), chosen.get("label", "")),
	})
	set_resolved(o)
	end()
