
from streamhub.utils import *

_CAT_ALIAS = {
	"soccer": "Football", "fussball": "Football", "fußball": "Football",
	"american football": "American Football", "nfl": "American Football",
	"ice hockey": "Hockey", "nhl": "Hockey",
	"basket": "Basketball", "nba": "Basketball",
	"motor sports": "Motorsport", "motorsports": "Motorsport",
	"formula 1": "Motorsport", "f1": "Motorsport",
	"baseball": "Baseball", "mlb": "Baseball",
	"tv shows": "Other", "sports": "Other",
}


def _cat_root(cat):
	base = (cat or "").split(".")[0].strip()
	base = re.split(r"\s*[:\-–]\s*", base)[0].strip()
	if not base:
		return "Other"
	low = base.lower()
	for k, v in _CAT_ALIAS.items():
		if low == k or low.startswith(k + " "):
			return v
	return base[:1].upper() + base[1:]


def _dlhd_events():
	if getSetting("dlhd") != "true":
		return []
	try:
		from streamhub.dlhd import fetch_schedule
		raw = fetch_schedule()
	except Exception:
		log(format_exc())
		return []
	out = []
	for ev in raw:
		chans = ev.get("channels") or []
		if not chans:
			continue
		title = ev.get("title", "")
		cat = ev.get("category") or ""
		if ":" in title and not cat:
			cat = title.split(":", 1)[0]
		out.append({
			"id": "dlhd_%s_%s" % (ev.get("time", ""), title[:40]),
			"title": re.sub(r"^[^:]{3,24}:\s*", "", title) or title,
			"category": _cat_root(cat or title),
			"desc": ev.get("time", ""),
			"score": "",
			"live": False,
			"source": "DLHD",
			"channels": chans,
		})
	return out


def _livetv_events():
	if getSetting("livetv") != "true":
		return []
	try:
		from streamhub.livetv import fetch_events
		evs = fetch_events()
	except Exception:
		log(format_exc())
		return []
	for e in evs:
		e["source"] = "LiveTV"
		e["category"] = _cat_root(e.get("category"))
	return evs


def _all_events():
	out = []
	with ThreadPoolExecutor(max_workers=2) as ex:
		futs = [ex.submit(_livetv_events), ex.submit(_dlhd_events)]
		for f in futs:
			try:
				out.extend(f.result() or [])
			except Exception:
				log(format_exc())
	return out


def index(params):
	try:
		events = _all_events()
	except Exception:
		log(format_exc())
		events = []
	if not events:
		dialog.notification("StreamHub Sport",
		                    "Keine Events gefunden (Quellen nicht erreichbar)",
		                    time=4000)
		end()
		return
	set_content("videos")
	set_category("Live Sport")

	live_n = sum(1 for e in events if e.get("live"))
	if live_n:
		addDir2("[B][COLOR lime]Jetzt LIVE[/COLOR][/B]  (%d)" % live_n,
		        "DefaultAddonPVRClient", "sport_list", filter="live")
	addDir2("[B]Alle Events[/B]  (%d)" % len(events),
	        "DefaultAddonPVRClient", "sport_list", filter="all")

	cats = {}
	for e in events:
		cats[e.get("category") or "Other"] = cats.get(e.get("category") or "Other", 0) + 1
	for cat in sorted(cats, key=lambda c: (-cats[c], c)):
		addDir2("%s  [COLOR grey](%d)[/COLOR]" % (cat, cats[cat]),
		        "DefaultAddonPVRClient", "sport_list", filter="cat", cat=cat)
	end()


def _sort_events(events):
	return sorted(events, key=lambda e: (
		0 if e.get("live") else 1,
		(e.get("category") or "").lower(),
		e.get("desc", ""),
		e.get("title", ""),
	))


def listing(params):
	mode = params.get("filter", "all")
	cat = params.get("cat", "")
	try:
		events = _all_events()
	except Exception:
		log(format_exc())
		events = []
	if mode == "live":
		events = [e for e in events if e.get("live")]
		title = "Jetzt LIVE"
	elif mode == "cat":
		events = [e for e in events if (e.get("category") or "Other") == cat]
		title = cat
	else:
		title = "Alle Events"
	if not events:
		dialog.notification("StreamHub Sport", "Keine Events", time=3000)
		end()
		return
	set_content("videos")
	set_category("Live Sport - %s" % title)
	for e in _sort_events(events):
		label = e.get("title", "?")
		if e.get("live"):
			label = "[COLOR lime]● LIVE[/COLOR]  %s" % label
			if e.get("score"):
				label += "  [COLOR yellow]%s[/COLOR]" % e["score"]
		elif e.get("desc"):
			t = e["desc"].split(" ")[0]
			label = "[COLOR grey]%s[/COLOR]  %s" % (t, label)
		cat_txt = e.get("category") or ""
		if cat_txt and cat_txt.lower() not in label.lower():
			label += "  [COLOR grey](%s)[/COLOR]" % cat_txt
		src = e.get("source") or ""
		if src:
			label += "  [COLOR grey]%s[/COLOR]" % src
		o = ListItem(label)
		o.setArt({"icon": "DefaultAddonPVRClient.png"})
		o.setProperty("IsPlayable", "true")
		info_tag = ListItemInfoTag(o, "video")
		info_tag.set_info({
			"title": e.get("title", ""),
			"plot": "[B]%s[/B]\n%s\n%s%s" % (
				e.get("title", ""), e.get("category", ""),
				e.get("desc", ""),
				("\n\n[COLOR lime]LIVE  %s[/COLOR]" % e.get("score", ""))
				if e.get("live") else ""),
		})
		add({"action": "sport_play",
		     "event": json.dumps({"title": e.get("title", ""),
		                          "url": e.get("url", ""),
		                          "source": src,
		                          "channels": e.get("channels") or [],
		                          "live": e.get("live")})}, o, False)
	end()


def play(params):
	try:
		ev = json.loads(params.get("event", "{}"))
	except Exception:
		fail_resolved("Event-Daten ungültig")
		return

	prog = StatusProgress("StreamHub")
	prog.update(10, "Suche Streams …")

	if (ev.get("source") or "") == "DLHD":
		order = [{"_dlhd": c["url"], "type": c.get("label", "Stream"),
		          "lang": "", "playable": c.get("playable")}
		         for c in (ev.get("channels") or []) if c.get("url")]
		order.sort(key=lambda c: 0 if c.get("playable") else 1)
	else:
		if not ev.get("url"):
			prog.close()
			fail_resolved("Event-URL fehlt")
			return
		try:
			from streamhub.livetv import fetch_links
			order = fetch_links(ev["url"])
		except Exception:
			log(format_exc())
			order = []
		order.sort(key=lambda l: (
			0 if (l.get("lang") or "").upper() == "DE"
			else 1 if (l.get("lang") or "").upper() == "EN" else 2,
			l.get("type", "")))

	if not order:
		prog.close()
		fail_resolved("Keine Streams für dieses Event")
		return
	prog.update(30, "%d Stream(s) gefunden" % len(order))

	host_select = getSetting("movies_host_select") == "true"
	if host_select and len(order) > 1:
		prog.close()
		labels = []
		for i, l in enumerate(order):
			lg = l.get("lang") or ""
			labels.append("%d. %s%s" % (
				i + 1, l.get("type", "?"),
				("  [COLOR yellow][%s][/COLOR]" % lg) if lg else ""))
		idx = selectDialog(labels, "Stream wählen — %s" % ev.get("title", ""))
		if idx < 0:
			fail_resolved()
			return
		order = [order[idx]]

	url, headers, chosen = None, None, None
	for i, l in enumerate(order):
		prog.update(30 + int(60 * (i + 1) / max(len(order), 1)),
		            "Löse %s auf …" % l.get("type", "?"))
		try:
			if l.get("_dlhd"):
				from streamhub.vjlive import resolve_link as live_resolve
				url, headers = live_resolve(l["_dlhd"])
			else:
				from streamhub.livetv import resolve_link
				url, headers = resolve_link(l)
		except Exception:
			log(format_exc())
			url, headers = None, None
		if url:
			chosen = l
			break
	prog.close()

	if not url:
		fail_resolved("Stream nicht abrufbar")
		return

	o = ListItem(ev.get("title", "Sport"))
	o.setProperty("IsPlayable", "true")
	inputstream = ("inputstream.ffmpegdirect"
	               if getSetting("hlsinputstream") == "0"
	               else "inputstream.adaptive")
	o.setProperty("inputstream", inputstream)
	if inputstream == "inputstream.ffmpegdirect":
		o.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
		o.setProperty("inputstream.ffmpegdirect.stream_mode", "timeshift")
		o.setProperty("inputstream.ffmpegdirect.open_mode", "ffmpeg")
		o.setProperty("inputstream.ffmpegdirect.manifest_type", "hls")
		o.setProperty("inputstream.ffmpegdirect.protocol_whitelist",
		              "http,https,tcp,tls,crypto")
		o.setProperty("inputstream.ffmpegdirect.stream_opts", ":".join(
			["http_persistent=1", "multiple_requests=1", "reconnect=1",
			 "reconnect_streamed=1", "reconnect_delay_max=2",
			 "timeout=10000000"]))
	else:
		o.setProperty("inputstream.adaptive.manifest_type", "hls")
		o.setProperty("inputstream.adaptive.stream_selection_type", "adaptive")
		o.setProperty("inputstream.adaptive.config",
		              '{"ssl_verify_peer":false}')
	if headers:
		if inputstream == "inputstream.adaptive":
			o.setProperty("%s.common_headers" % inputstream, headers)
			o.setProperty("%s.stream_headers" % inputstream, headers)
		else:
			url += "|" + headers
	o.setPath(url)
	info_tag = ListItemInfoTag(o, "video")
	info_tag.set_info({
		"title": ev.get("title", ""),
		"plot": "[B]%s[/B]\nQuelle: %s (livetv.sx)" % (
			ev.get("title", ""), (chosen or {}).get("type", "?")),
	})
	play_directly(url, o)
