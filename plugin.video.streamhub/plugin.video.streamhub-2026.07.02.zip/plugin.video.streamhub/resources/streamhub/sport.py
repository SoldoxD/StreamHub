
from streamhub.utils import *

_CAT_ICONS = {
	"football": "DefaultAddonPVRClient.png",
	"soccer": "DefaultAddonPVRClient.png",
	"tennis": "DefaultAddonPVRClient.png",
	"basketball": "DefaultAddonPVRClient.png",
	"hockey": "DefaultAddonPVRClient.png",
	"cricket": "DefaultAddonPVRClient.png",
}


def _cat_root(cat):
	return (cat or "Other").split(".")[0].strip() or "Other"


def index(params):
	from streamhub.livetv import fetch_events
	try:
		events = fetch_events()
	except Exception:
		log(format_exc())
		events = []
	if not events:
		dialog.notification("StreamHub Sport",
		                    "Keine Events gefunden (livetv.sx nicht erreichbar)",
		                    time=4000)
		end()
		return
	set_content("videos")
	set_category("Live Sport")

	live_n = sum(1 for e in events if e.get("live"))
	addDir2("[B][COLOR lime]Jetzt LIVE[/COLOR][/B]  (%d)" % live_n,
	        "DefaultAddonPVRClient", "sport_list", filter="live")
	addDir2("[B]Alle Events[/B]  (%d)" % len(events),
	        "DefaultAddonPVRClient", "sport_list", filter="all")

	cats = {}
	for e in events:
		cats.setdefault(_cat_root(e.get("category")), 0)
		cats[_cat_root(e.get("category"))] += 1
	for cat in sorted(cats, key=lambda c: (-cats[c], c)):
		addDir2("%s  [COLOR grey](%d)[/COLOR]" % (cat, cats[cat]),
		        "DefaultAddonPVRClient", "sport_list", filter="cat", cat=cat)
	end()


def _sort_events(events):
	return sorted(events, key=lambda e: (
		0 if e.get("live") else 1,
		_cat_root(e.get("category")).lower(),
		e.get("desc", ""),
		e.get("title", ""),
	))


def listing(params):
	from streamhub.livetv import fetch_events
	mode = params.get("filter", "all")
	cat = params.get("cat", "")
	try:
		events = fetch_events()
	except Exception:
		log(format_exc())
		events = []
	if mode == "live":
		events = [e for e in events if e.get("live")]
		title = "Jetzt LIVE"
	elif mode == "cat":
		events = [e for e in events if _cat_root(e.get("category")) == cat]
		title = cat
	else:
		title = "Alle Events"
	if not events:
		dialog.notification("StreamHub Sport", "Keine Events", time=3000)
		end()
		return
	set_content("videos")
	set_category("Live Sport - %s" % title)
	for e in _sort_events(events):
		label = e.get("title", "?")
		if e.get("live"):
			label = "[COLOR lime]● LIVE[/COLOR]  %s" % label
			if e.get("score"):
				label += "  [COLOR yellow]%s[/COLOR]" % e["score"]
		elif e.get("desc"):
			t = e["desc"].split(" ")[0]
			label = "[COLOR grey]%s[/COLOR]  %s" % (t, label)
		cat_txt = _cat_root(e.get("category"))
		if cat_txt and cat_txt.lower() not in label.lower():
			label += "  [COLOR grey](%s)[/COLOR]" % cat_txt
		o = ListItem(label)
		o.setArt({"icon": "DefaultAddonPVRClient.png"})
		o.setProperty("IsPlayable", "true")
		info_tag = ListItemInfoTag(o, "video")
		info_tag.set_info({
			"title": e.get("title", ""),
			"plot": "[B]%s[/B]\n%s\n%s%s" % (
				e.get("title", ""), e.get("category", ""),
				e.get("desc", ""),
				("\n\n[COLOR lime]LIVE  %s[/COLOR]" % e.get("score", ""))
				if e.get("live") else ""),
		})
		add({"action": "sport_play",
		     "event": json.dumps({"title": e.get("title", ""),
		                          "url": e.get("url", ""),
		                          "live": e.get("live")})}, o, False)
	end()


def play(params):
	from streamhub.livetv import fetch_links, resolve_link
	from streamhub.movies import _start_playback
	try:
		ev = json.loads(params.get("event", "{}"))
	except Exception:
		fail_resolved("Event-Daten ungültig")
		return
	if not ev.get("url"):
		fail_resolved("Event-URL fehlt")
		return

	prog = StatusProgress("StreamHub")
	prog.update(10, "Suche Streams …")
	try:
		links = fetch_links(ev["url"])
	except Exception:
		log(format_exc())
		links = []
	if not links:
		prog.close()
		fail_resolved("Keine Streams für dieses Event")
		return

	def _rank(l):
		lang = (l.get("lang") or "").upper()
		return (0 if lang == "DE" else 1 if lang == "EN" else 2,
		        l.get("type", ""))
	links = sorted(links, key=_rank)
	prog.update(30, "%d Stream(s) gefunden" % len(links))

	host_select = getSetting("movies_host_select") == "true"
	if host_select and len(links) > 1:
		prog.close()
		labels = ["%d. %s  [COLOR yellow][%s][/COLOR]" % (
			i + 1, l.get("type", "?"), l.get("lang", "?"))
			for i, l in enumerate(links)]
		idx = selectDialog(labels, "Stream wählen — %s" % ev.get("title", ""))
		if idx < 0:
			fail_resolved()
			return
		order = [links[idx]]
	else:
		order = links

	url, headers, chosen = None, None, None
	for i, l in enumerate(order):
		prog.update(30 + int(60 * (i + 1) / max(len(order), 1)),
		            "Löse %s auf …" % l.get("type", "?"))
		try:
			url, headers = resolve_link(l)
		except Exception:
			log(format_exc())
			url, headers = None, None
		if url:
			chosen = l
			break
	prog.close()

	if not url:
		fail_resolved("Stream nicht abrufbar")
		return

	o = ListItem(ev.get("title", "Sport"))
	o.setProperty("IsPlayable", "true")
	inputstream = ("inputstream.ffmpegdirect"
	               if getSetting("hlsinputstream") == "0"
	               else "inputstream.adaptive")
	o.setProperty("inputstream", inputstream)
	if inputstream == "inputstream.ffmpegdirect":
		o.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
		o.setProperty("inputstream.ffmpegdirect.stream_mode", "timeshift")
		o.setProperty("inputstream.ffmpegdirect.open_mode", "ffmpeg")
		o.setProperty("inputstream.ffmpegdirect.manifest_type", "hls")
		o.setProperty("inputstream.ffmpegdirect.protocol_whitelist",
		              "http,https,tcp,tls,crypto")
		o.setProperty("inputstream.ffmpegdirect.stream_opts", ":".join(
			["http_persistent=1", "multiple_requests=1", "reconnect=1",
			 "reconnect_streamed=1", "reconnect_delay_max=2",
			 "timeout=10000000"]))
	else:
		o.setProperty("inputstream.adaptive.manifest_type", "hls")
		o.setProperty("inputstream.adaptive.stream_selection_type", "adaptive")
		o.setProperty("inputstream.adaptive.config",
		              '{"ssl_verify_peer":false}')
	if headers:
		if inputstream == "inputstream.adaptive":
			o.setProperty("%s.common_headers" % inputstream, headers)
			o.setProperty("%s.stream_headers" % inputstream, headers)
		else:
			url += "|" + headers
	o.setPath(url)
	info_tag = ListItemInfoTag(o, "video")
	info_tag.set_info({
		"title": ev.get("title", ""),
		"plot": "[B]%s[/B]\nQuelle: %s (livetv.sx)" % (
			ev.get("title", ""), (chosen or {}).get("type", "?")),
	})
	play_directly(url, o)
