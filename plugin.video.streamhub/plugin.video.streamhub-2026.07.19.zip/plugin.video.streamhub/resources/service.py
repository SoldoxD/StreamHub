
import io
import os
import re
import sys
import time
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


ADDON_ID = "plugin.video.streamhub"
MANIFEST_URL = "https://soldoxd.github.io/StreamHub/addons.xml"
ZIP_URL_FMT = "https://soldoxd.github.io/StreamHub/plugin.video.streamhub/plugin.video.streamhub-{}.zip"
CHECK_INTERVAL_HOURS = 24
STARTUP_DELAY = 30


def _log(msg, level=xbmc.LOGINFO):
	xbmc.log("[StreamHub-Updater] " + str(msg), level)


def _addon():
	return xbmcaddon.Addon(ADDON_ID)


def _setting(key, default=""):
	try:
		return _addon().getSetting(key) or default
	except Exception:
		return default


def _installed_version():
	try:
		return _addon().getAddonInfo("version")
	except Exception:
		return "0.0.0"


def _addon_path():
	return xbmcvfs.translatePath(_addon().getAddonInfo("path"))


def _ensure_path_for_import():
	resources = os.path.join(_addon_path(), "resources")
	if resources not in sys.path:
		sys.path.insert(0, resources)


def _http_session():
	_ensure_path_for_import()
	try:
		import requests as _r
		return _r.Session()
	except Exception:
		pass
	from streamhub import _http as _r
	return _r.Session()


def _fetch_remote_version():
	try:
		sess = _http_session()
		r = sess.request("GET", MANIFEST_URL, timeout=10)
		if r.status_code != 200:
			return None
		m = re.search(
			r'<addon\s+id="' + re.escape(ADDON_ID) + r'"\s+name="[^"]*"\s+version="([^"]+)"',
			r.text,
		)
		return m.group(1) if m else None
	except Exception as e:
		_log("manifest fetch failed: %s" % e, xbmc.LOGWARNING)
		return None


def _version_tuple(v):
	out = []
	for x in str(v or "").split("."):
		try:
			out.append(int(x))
		except Exception:
			out.append(0)
	return tuple(out)


def _is_newer(remote, installed):
	return _version_tuple(remote) > _version_tuple(installed)


def _download_zip(version):
	try:
		sess = _http_session()
		r = sess.request("GET", ZIP_URL_FMT.format(version), timeout=60)
		if r.status_code != 200:
			_log("zip download HTTP %s" % r.status_code, xbmc.LOGWARNING)
			return None
		return r.content
	except Exception as e:
		_log("zip download failed: %s" % e, xbmc.LOGWARNING)
		return None


def _install_zip(zip_bytes):
	try:
		addons_dir = xbmcvfs.translatePath("special://home/addons/")
		z = zipfile.ZipFile(io.BytesIO(zip_bytes))
		names = z.namelist()
		top_dirs = sorted({n.split("/", 1)[0] for n in names})
		if ADDON_ID not in top_dirs:
			_log("zip has wrong top-level: %s" % top_dirs, xbmc.LOGERROR)
			return False
		z.extractall(addons_dir)
		return True
	except Exception as e:
		_log("install failed: %s" % e, xbmc.LOGERROR)
		return False


def _last_check_ts():
	try:
		s = _setting("_last_update_check", "0")
		return int(s) if s.isdigit() else 0
	except Exception:
		return 0


def _set_last_check_ts(ts):
	try:
		_addon().setSetting("_last_update_check", str(int(ts)))
	except Exception:
		pass


def check_for_update(force=False):
	installed = _installed_version()
	remote = _fetch_remote_version()
	_log("installed=%s  remote=%s" % (installed, remote))
	if not remote:
		return False
	if not _is_newer(remote, installed):
		_log("already up to date")
		return False

	auto = _setting("auto_update") == "true"
	if not auto and not force:
		ok = xbmcgui.Dialog().yesno(
			"StreamHub Update",
			"Eine neue Version ist verfuegbar:\n\n"
			"  installiert: " + installed + "\n"
			"  neu:         " + remote + "\n\n"
			"Jetzt installieren?",
		)
		if not ok:
			return False

	xbmcgui.Dialog().notification("StreamHub", "Update %s wird geladen..." % remote, time=4000)
	zip_bytes = _download_zip(remote)
	if not zip_bytes:
		xbmcgui.Dialog().notification("StreamHub", "Download fehlgeschlagen", time=5000)
		return False
	if not _install_zip(zip_bytes):
		xbmcgui.Dialog().notification("StreamHub", "Installation fehlgeschlagen", time=5000)
		return False

	try:
		xbmc.executebuiltin("UpdateLocalAddons")
	except Exception:
		pass

	xbmcgui.Dialog().ok(
		"StreamHub",
		"Update " + remote + " installiert.\n\n"
		"Bitte Kodi neu starten, damit die neue Version aktiv wird.",
	)
	return True


def _add_resources_path():
	try:
		p = os.path.join(xbmcvfs.translatePath(_addon().getAddonInfo("path")), "resources")
		if p not in sys.path:
			sys.path.insert(0, p)
	except Exception:
		pass


def _apply_buffer():
	try:
		_add_resources_path()
		from streamhub import buffer
		if buffer.apply_if_changed():
			_log("buffer settings written to advancedsettings.xml")
	except Exception as e:
		_log("buffer apply failed: %s" % e, xbmc.LOGWARNING)


class ResumeTracker(xbmc.Player):
	PROP = "streamhub_playing"

	def __init__(self):
		super(ResumeTracker, self).__init__()
		self._reset()

	def _reset(self):
		self._key = None
		self._title = ""
		self._pos = 0
		self._total = 0
		self._seeked = False

	def _pickup(self):
		try:
			from streamhub.utils import home
			import json
			raw = home.getProperty(self.PROP)
			if not raw:
				return
			d = json.loads(raw)
			self._key = d.get("key") or None
			self._title = d.get("title", "")
			self._pending_resume = int(d.get("resume") or 0)
			self._seeked = False
			home.clearProperty(self.PROP)
		except Exception:
			pass

	def onAVStarted(self):
		self._pickup()
		self._maybe_seek()

	def onPlayBackStarted(self):
		if not self._key:
			self._pickup()

	def _maybe_seek(self):
		if self._seeked or not self._key:
			return
		try:
			pos = getattr(self, "_pending_resume", 0)
			if pos and pos >= 30:
				# wait until the stream reports a duration, then seek
				for _ in range(20):
					if self.isPlaying() and (self.getTotalTime() or 0) > pos:
						self.seekTime(pos)
						break
					xbmc.sleep(250)
			self._seeked = True
		except Exception:
			pass

	def sample(self):
		if not self._key:
			return
		try:
			if self.isPlaying():
				t = self.getTime()
				tot = self.getTotalTime()
				if tot and tot > 0:
					self._pos = int(t)
					self._total = int(tot)
		except Exception:
			pass

	def _commit(self, ended=False):
		if not self._key:
			return
		try:
			from streamhub import resume
			pos = self._total if ended else self._pos
			if self._total > 0:
				resume.record(self._key, pos, self._total, self._title)
		except Exception:
			_log("resume commit failed", xbmc.LOGWARNING)
		self._reset()

	def onPlayBackStopped(self):
		self._commit(ended=False)

	def onPlayBackEnded(self):
		self._commit(ended=True)

	def onPlayBackError(self):
		self._reset()


def main():
	_log("service started for %s v%s" % (ADDON_ID, _installed_version()))
	monitor = xbmc.Monitor()

	_apply_buffer()

	if monitor.waitForAbort(STARTUP_DELAY):
		return

	_add_resources_path()
	tracker = None
	try:
		tracker = ResumeTracker()
		_log("resume tracker active")
	except Exception as e:
		_log("resume tracker unavailable: %s" % e, xbmc.LOGWARNING)

	now = int(time.time())
	last = _last_check_ts()
	due = (now - last) >= CHECK_INTERVAL_HOURS * 3600
	if due or _setting("update_on_start") == "true":
		try:
			check_for_update()
		except Exception as e:
			_log("update check error: %s" % e, xbmc.LOGWARNING)
		_set_last_check_ts(time.time())

	while not monitor.abortRequested():
		if monitor.waitForAbort(1):
			break
		if tracker is not None:
			tracker.sample()
		if (time.time() - _last_check_ts()) >= CHECK_INTERVAL_HOURS * 3600:
			try:
				check_for_update()
			except Exception as e:
				_log("update check error: %s" % e, xbmc.LOGWARNING)
			_set_last_check_ts(time.time())

	_log("service stopped")


if __name__ == "__main__":
	main()
