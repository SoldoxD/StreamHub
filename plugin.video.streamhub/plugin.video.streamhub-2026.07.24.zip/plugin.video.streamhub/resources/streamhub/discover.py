from streamhub.utils import (request_json, log, format_exc, addDir, addDir2,
                             set_content, set_category, end, ListItem, add,
                             ListItemInfoTag, sys, quote)

BASE = "https://v3-cinemeta.strem.io"
PAGE = 100

_CATS = (("top", "Populär"), ("imdbRating", "Top bewertet"), ("year", "Neu / Nach Jahr"))

_GENRES = ("Action", "Adventure", "Animation", "Comedy", "Crime", "Documentary",
           "Drama", "Family", "Fantasy", "History", "Horror", "Music", "Mystery",
           "Romance", "Sci-Fi", "Thriller", "War", "Western")


def _mtype(t):
	return "series" if t == "series" else "movie"


def _catalog(mtype, cat, genre=None, skip=0):
	url = "%s/catalog/%s/%s" % (BASE, mtype, cat)
	extra = []
	if genre:
		extra.append("genre=%s" % quote(genre))
	if skip:
		extra.append("skip=%d" % skip)
	if extra:
		url += "/" + "&".join(extra)
	url += ".json"
	try:
		data = request_json("GET", url, timeout=12, retries=1)
		return (data or {}).get("metas") or []
	except Exception:
		log("discover catalog failed: %s\n%s" % (url, format_exc()))
		return []


def index(params):
	mtype = _mtype(params.get("t"))
	label_kind = "Serien" if mtype == "series" else "Filme"
	set_content("files")
	set_category("Entdecken – %s" % label_kind)
	for cat, name in _CATS:
		addDir2(name, "DefaultMovies" if mtype == "movie" else "DefaultTVShows",
		        "disc_cat", t=mtype, cat=cat)
	addDir2("Nach Genre", "DefaultGenre", "disc_genres", t=mtype)
	end()


def genres(params):
	mtype = _mtype(params.get("t"))
	set_content("files")
	set_category("Genres")
	for g in _GENRES:
		addDir2(g, "DefaultGenre", "disc_cat", t=mtype, cat="top", genre=g)
	end()


def cat(params):
	mtype = _mtype(params.get("t"))
	c = params.get("cat", "top")
	genre = params.get("genre")
	try:
		skip = int(params.get("skip") or 0)
	except (TypeError, ValueError):
		skip = 0
	metas = _catalog(mtype, c, genre, skip)
	set_content("tvshows" if mtype == "series" else "movies")
	title = genre or dict(_CATS).get(c, "Entdecken")
	set_category("%s – %s" % ("Serien" if mtype == "series" else "Filme", title))
	if not metas:
		end()
		return
	for m in metas:
		name = m.get("name") or "?"
		year = str(m.get("year") or "").split("–")[0].strip()
		gl = ", ".join((m.get("genres") or [])[:3])
		rating = m.get("imdbRating")
		label = name + (" (%s)" % year if year else "")
		if rating:
			label += "  [COLOR grey]★ %s[/COLOR]" % rating
		o = ListItem(label)
		poster = m.get("poster")
		if poster:
			o.setArt({"poster": poster, "thumb": poster,
			          "fanart": m.get("background") or poster})
		info = {"title": name, "plot": m.get("description") or "",
		        "genre": gl, "mediatype": "tvshow" if mtype == "series" else "movie"}
		if year.isdigit():
			info["year"] = int(year)
		if rating:
			try:
				info["rating"] = float(rating)
			except (TypeError, ValueError):
				pass
		ListItemInfoTag(o, 'video').set_info(info)
		add({"action": "disc_open", "t": mtype, "q": name, "year": year}, o, True)
	nxt = dict(params)
	nxt["action"] = "disc_cat"
	nxt["skip"] = str(skip + PAGE)
	addDir(">>> Weiter", nxt)
	end()


def open_title(params):
	q = (params.get("q") or "").strip()
	if not q:
		end()
		return
	if _mtype(params.get("t")) == "series":
		from streamhub import series
		series._search_and_list(q)
	else:
		from streamhub import movies
		movies._search_and_list(q)
