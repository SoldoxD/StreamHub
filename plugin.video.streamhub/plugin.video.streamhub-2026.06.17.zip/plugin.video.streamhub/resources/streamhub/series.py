
from streamhub.utils import *

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")


def _ua_headers(referer=None, **extra):
	h = {"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"}
	if referer:
		h["Referer"] = referer
	h.update(extra)
	return h


def _normalize_title(t):
	t = re.sub(r"[^\w\s]", " ", t or "")
	t = re.sub(r"\s+", " ", t).strip().lower()
	return t




class VavooSeriesProvider:
	name = "vavoo"

	def search(self, query, max_results=20):
		from html import unescape
		try:
			from streamhub.vjackson import callApi2
			q = query.replace(".", "%2E")
			res = callApi2("list", {"id": "series.popular.search=" + q})
			items = res.get("data") if isinstance(res, dict) else res
			if not items:
				return []
		except Exception as e:
			log("vavoo series search failed: %s" % e)
			return []
		out = []
		for it in items[:max_results]:
			tid = it.get("id", "")
			tmdb = tid.split(".")[1] if tid.startswith("series.") and "." in tid else None
			out.append({"tmdb_id": tmdb,
			            "title": unescape(it.get("name", "")),
			            "year": str(it.get("year", "") or ""),
			            "poster": it.get("poster"),
			            "plot": it.get("description"),
			            "provider": self.name,
			            "vavoo_id": tid})
		return out

	def _vid(self, series):
		tmdb = series.get("tmdb_id")
		if not tmdb:
			return None
		return series.get("vavoo_id") or ("series.%s" % tmdb)

	def get_seasons(self, series):
		vid = self._vid(series)
		if not vid:
			return []
		meta = get_meta({"id": vid})
		if not isinstance(meta, dict):
			return []
		seasons = meta.get("seasons") or []
		out = []


		poster_base = "https://image.tmdb.org/t/p/w342"
		for s in seasons:
			pp = s.get("poster_path")
			out.append({
				"season_number": s.get("season_number"),
				"name": s.get("name") or "Staffel %s" % s.get("season_number"),
				"episode_count": s.get("episode_count"),
				"poster": (poster_base + pp) if pp else series.get("poster"),
			})
		return out

	def get_episode_count(self, series, season_number):
		vid = self._vid(series)
		if not vid:
			return 0
		meta = get_meta({"id": vid, "s": str(season_number)})
		if not isinstance(meta, dict):
			return 0
		return int(meta.get("infos", {}).get("sortepisode") or 0)

	def get_episode_hosts(self, series, season, episode):
		tmdb = series.get("tmdb_id")
		if not tmdb:
			return []
		try:
			from streamhub.vjackson import getAuthSignature
			_headers = {
				"user-agent": "MediaHubMX/2",
				"content-type": "application/json; charset=utf-8",
				"accept-encoding": "gzip",
				"mediahubmx-signature": getAuthSignature(),
			}
			_data = {
				"language": "de", "region": "AT", "type": "series",
				"ids": {"tmdb_id": tmdb},
				"name": series.get("title", ""),
				"episode": {"season": str(season), "episode": str(episode)},
				"clientVersion": "3.0.2",
			}
			mirrors = request_json(
				"POST", "https://vavoo.to/mediahubmx-source.json",
				json=_data, headers=_headers, timeout=10, retries=1) or []
		except Exception as e:
			log("vavoo episode hosts failed: %s" % e)
			return []
		hosts = []
		for a in mirrors:
			url = a.get("url")
			if not url:
				continue
			host = urlparse(url).netloc or "?"
			if "streamz" in host:
				continue
			q = a.get("tag", "")
			from streamhub.movies import _norm_lang
			lang = _norm_lang(a.get("languages") or [])
			label = "%s%s (vavoo)" % (host, (" " + q) if q else "")
			hosts.append({
				"provider": self.name,
				"host": host,
				"label": label,
				"url": url,
				"resolver": "vavoo_chain",
				"quality": q,
				"lang": lang,
			})
		return hosts


class Movies67SeriesProvider:
	name = "67movies"
	virtual = True

	def search(self, query, max_results=20):
		return []

	def get_seasons(self, series):
		return []

	def get_episode_count(self, series, season_number):
		return 0

	def get_episode_hosts(self, series, season, episode):
		tmdb = series.get("tmdb_id")
		if not tmdb:
			return []
		embed = "https://111movies.net/tv/%s/%s/%s" % (tmdb, season, episode)
		return [{
			"provider": self.name,
			"host": "111movies",
			"label": "111movies (TMDB %s S%sE%s)" % (tmdb, season, episode),
			"url": embed,
			"resolver": "embed_generic",
			"referer": "https://67movies.net/",
			"lang": "OV",
		}]


def _enabled_providers():
	provs = []
	if getSetting("vavoo") == "true":
		provs.append(VavooSeriesProvider())
	if getSetting("movies67") == "true":
		provs.append(Movies67SeriesProvider())


	return provs




def _merge_results(per_provider):
	by_norm = {}
	merged_order = []
	for provider, results in per_provider:
		for m in results:
			norm = _normalize_title(m.get("title", ""))
			if not norm:
				continue
			entry = by_norm.get(norm)
			if entry is None:
				entry = {
					"title": m.get("title") or "",
					"year": m.get("year"),
					"tmdb_id": m.get("tmdb_id"),
					"poster": m.get("poster"),
					"plot": m.get("plot"),
					"_norm": norm,
					"_hits": [],
				}
				by_norm[norm] = entry
				merged_order.append(entry)
			entry["_hits"].append((provider, m))
			for k in ("tmdb_id", "year", "poster", "plot"):
				if not entry.get(k) and m.get(k):
					entry[k] = m[k]
			if len(m.get("title") or "") > len(entry.get("title") or ""):
				entry["title"] = m["title"]
	return merged_order


def search(params):
	cacheOk, history = get_cache("series_search")
	if not cacheOk:
		history = {}
	kb = xbmc.Keyboard("", "StreamHub - Serien Suche", False)
	kb.doModal()
	if not kb.isConfirmed():
		return
	query = kb.getText().strip()
	if not query:
		return
	history[query] = True
	set_cache("series_search", history, False)
	_search_and_list(query)


def _search_and_list(query):
	provs = _enabled_providers()
	if not provs:
		dialog.notification("StreamHub", "Keine Quellen aktiviert", time=3000)
		return
	per_provider = []
	with ThreadPoolExecutor(max_workers=max(len(provs), 1)) as ex:
		futs = {ex.submit(p.search, query, 20): p for p in provs}
		for fut in as_completed(futs):
			p = futs[fut]
			try:
				per_provider.append((p.name, fut.result() or []))
			except Exception:
				log(format_exc())
				per_provider.append((p.name, []))
	merged = _merge_results(per_provider)
	if not merged:
		dialog.notification("StreamHub",
		                    "Keine Serien für: %s" % query, time=3000)
		return
	set_content("tvshows")
	set_category("Serien-Suche: %s" % query)
	prov_objs = _enabled_providers()
	for m in merged:
		providers_hit = {p for p, _ in m["_hits"]}
		for p in prov_objs:
			if getattr(p, "virtual", False) and m.get("tmdb_id"):
				providers_hit.add(p.name)
		badge = "+".join(p[:1].upper() for p in sorted(providers_hit))
		year_part = " (%s)" % m["year"] if m.get("year") else ""
		label = "%s%s  [COLOR grey](%s)[/COLOR]" % (
			m.get("title", "?"), year_part, badge)
		o = ListItem(label)
		if m.get("poster"):
			o.setArt({"poster": m["poster"], "thumb": m["poster"]})
		info_year = None
		if m.get("year"):
			y = str(m["year"]).strip()
			if y.isdigit():
				info_year = int(y)
		info_tag = ListItemInfoTag(o, 'video')
		info_tag.set_info({
			"title": m.get("title", ""),
			"year": info_year,
			"plot": (m.get("plot") or "") +
			        "\n\n[B]Quellen:[/B] " + ", ".join(sorted(providers_hit)),
		})
		params = {
			"action": "series_seasons",
			"series": json.dumps({
				"title": m.get("title", ""),
				"year": m.get("year"),
				"tmdb_id": m.get("tmdb_id"),
				"poster": m.get("poster"),
				"plot": m.get("plot"),
				"hits": [{"provider": pn, **mv} for pn, mv in m["_hits"]],
			}),
		}
		add(params, o, True)
	end()




def seasons(params):
	try:
		series = json.loads(params.get("series", "{}"))
	except Exception:
		showFailedNotification("Series-Daten ungültig")
		return

	vavoo_hit = None
	for h in series.get("hits", []):
		if h.get("provider") == "vavoo":
			vavoo_hit = h
			break
	if not vavoo_hit:


		dialog.notification("StreamHub",
		                    "Keine Saison-Metadaten verfügbar (Vavoo deaktiviert?)",
		                    time=4000)
		return
	provider = VavooSeriesProvider()
	seasons_list = provider.get_seasons(vavoo_hit)
	if not seasons_list:
		dialog.notification("StreamHub", "Keine Staffeln gefunden", time=3000)
		return

	if len(seasons_list) == 1:
		s = seasons_list[0]
		_list_episodes(series, vavoo_hit, s.get("season_number"))
		return
	set_content("seasons")
	set_category(series.get("title", "Serie"))
	for s in seasons_list:
		sn = s.get("season_number")
		label = s.get("name") or "Staffel %s" % sn
		if s.get("episode_count"):
			label = "%s  [COLOR grey](%s Episoden)[/COLOR]" % (label, s["episode_count"])
		o = ListItem(label)
		if s.get("poster"):
			o.setArt({"poster": s["poster"], "thumb": s["poster"]})
		info_tag = ListItemInfoTag(o, 'video')
		info_tag.set_info({
			"title": label,
			"season": int(sn) if sn is not None else None,
		})
		params = {
			"action": "series_episodes",
			"series": json.dumps(series),
			"season": str(sn),
		}
		add(params, o, True)
	end()




def episodes(params):
	try:
		series = json.loads(params.get("series", "{}"))
	except Exception:
		showFailedNotification("Series-Daten ungültig")
		return
	season = params.get("season")
	if not season:
		showFailedNotification("Staffel fehlt")
		return
	vavoo_hit = None
	for h in series.get("hits", []):
		if h.get("provider") == "vavoo":
			vavoo_hit = h
			break
	if not vavoo_hit:
		showFailedNotification("Vavoo-Metadaten fehlen")
		return
	_list_episodes(series, vavoo_hit, season)


def _list_episodes(series, vavoo_hit, season):
	provider = VavooSeriesProvider()
	count = provider.get_episode_count(vavoo_hit, season)
	if count <= 0:
		dialog.notification("StreamHub", "Keine Episoden gefunden", time=3000)
		return
	set_content("episodes")
	set_category("%s - Staffel %s" % (series.get("title", ""), season))
	for ep in range(1, count + 1):
		label = "S%sE%s" % (str(season).zfill(2), str(ep).zfill(2))
		o = ListItem(label)
		o.setProperty("IsPlayable", "true")
		if series.get("poster"):
			o.setArt({"poster": series["poster"], "thumb": series["poster"]})
		info_tag = ListItemInfoTag(o, 'video')
		info_tag.set_info({
			"title": label,
			"season": int(season) if str(season).isdigit() else None,
			"episode": ep,
			"tvshowtitle": series.get("title", ""),
		})
		params = {
			"action": "series_play",
			"series": json.dumps(series),
			"season": str(season),
			"episode": str(ep),
		}
		add(params, o, False)
	end()




def _check_host_alive(host, timeout=3):
	url = host.get("url", "")
	if not url:
		return False
	if "vavoo.to" in url or host.get("provider") == "vavoo":
		return True
	try:
		headers = {"User-Agent": UA}
		if host.get("referer"):
			headers["Referer"] = host["referer"]
		r = request("HEAD", url, headers=headers, timeout=timeout,
		            retries=0, allow_redirects=True)
		if r.status_code in (405, 501):
			r = request("GET", url, headers={**headers, "Range": "bytes=0-0"},
			            timeout=timeout, retries=0, stream=True,
			            allow_redirects=True)
		return r.status_code < 400
	except Exception:
		return False


def _sortkey(h):
	from streamhub.movies import _sortkey as msk
	return msk(h)


def _gather_episode_hosts(series, season, episode):
	provs = _enabled_providers()
	hits_by_provider = {}
	for p in provs:
		hit = None
		for h in series.get("hits", []):
			if h.get("provider") == p.name:
				hit = h
				break
		if hit is None and getattr(p, "virtual", False) and series.get("tmdb_id"):
			hit = series
		if hit is not None:
			hits_by_provider[p.name] = (p, hit)
	all_hosts = []
	if hits_by_provider:
		with ThreadPoolExecutor(max_workers=max(len(hits_by_provider), 1)) as ex:
			futs = {ex.submit(p.get_episode_hosts, hit, season, episode): pname
			        for pname, (p, hit) in hits_by_provider.items()}
			for fut in as_completed(futs):
				try:
					hs = fut.result() or []
					all_hosts.extend(hs)
				except Exception:
					log(format_exc())
	all_hosts.sort(key=_sortkey)
	return all_hosts


def play(params):
	try:
		series = json.loads(params.get("series", "{}"))
	except Exception:
		fail_resolved("Series-Daten ungültig")
		return
	season = params.get("season")
	episode = params.get("episode")
	if not season or not episode:
		fail_resolved("Episoden-Daten fehlen")
		return

	manual = params.get("manual") == "true"
	host_select = getSetting("movies_host_select") == "true" or manual

	cache_key = {"_ep_hosts": series.get("tmdb_id") or series.get("title", ""),
	             "s": season, "e": episode}
	cacheOk, cached_hosts = get_cache(cache_key)
	if cacheOk and isinstance(cached_hosts, list) and cached_hosts:
		all_hosts = cached_hosts
	else:
		all_hosts = _gather_episode_hosts(series, season, episode)
		if all_hosts:
			set_cache(cache_key, all_hosts, timeout=1)

	if not all_hosts:
		fail_resolved("Keine Hoster für diese Episode")
		return

	from streamhub import movies
	ep_movie = {
		"title": "%s - S%sE%s" % (series.get("title", ""), season, episode),
		"year": series.get("year"),
		"poster": series.get("poster"),
		"plot": series.get("plot"),
	}
	all_hosts = sorted(all_hosts, key=movies._sortkey)
	deep_check = getSetting("movies_deep_check") == "true"

	if host_select:
		if deep_check and len(all_hosts) > 1:
			working = movies._resolve_verify_bulk(all_hosts, deadline_s=8.0)
			if not working:
				fail_resolved("Kein funktionierender Hoster gefunden")
				return
			labels = [movies._host_display(h, i + 1) for i, (h, _) in enumerate(working)]
			idx = selectDialog(labels, "Hoster wählen — %s S%sE%s" % (
				series.get("title", ""), season, episode))
			if idx < 0:
				fail_resolved()
				return
			chosen, stream = working[idx]
			movies._start_playback(ep_movie, chosen, stream)
			return
		labels = [movies._host_display(h, i + 1) for i, h in enumerate(all_hosts)]
		idx = selectDialog(labels, "Hoster wählen — %s S%sE%s" % (
			series.get("title", ""), season, episode))
		if idx < 0:
			fail_resolved()
			return
		chosen = all_hosts[idx]
		stream = movies._resolve_host(chosen)
		if stream:
			movies._start_playback(ep_movie, chosen, stream)
			return
		fail_resolved("Stream nicht abrufbar — bitte anderen Hoster wählen")
		return

	chosen, stream = movies._race_hosts(all_hosts, deadline_s=6.0, verify=deep_check)
	if stream:
		movies._start_playback(ep_movie, chosen, stream)
		return
	fail_resolved("Kein Hoster spielbar")
