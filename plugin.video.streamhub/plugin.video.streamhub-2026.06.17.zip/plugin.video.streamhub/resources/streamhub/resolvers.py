
from streamhub.utils import request, log, quote, urlparse, base64, re, format_exc
import json as _json
import random as _random
import string as _string
import time as _time

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")


def _hdr(referer=None):
	h = {"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"}
	if referer:
		h["Referer"] = referer
	return h


def _hdr_qs(referer_origin):
	return "Referer=%s&User-Agent=%s" % (
		quote(referer_origin, safe=""), quote(UA, safe=""))


VOE_HOSTS = ("voe.sx", "voe-un", "voe-net", "voe-net", "voeun", "voeunblock",
             "voe-network", "cloudwindow")

DOOD_HOSTS = ("dood.", "doodstream", "d0000d", "d000d", "ds2play", "dooood",
              "doods.", "vidply", "playmogo", "dood.to", "dood.watch",
              "dood.so", "dood.la", "dood.ws", "dood.yt", "dood.re",
              "all3do", "do0od", "doodcdn", "dooodster")


def _rot13(s):
	out = []
	for c in s:
		o = ord(c)
		if 65 <= o <= 90:
			out.append(chr((o - 65 + 13) % 26 + 65))
		elif 97 <= o <= 122:
			out.append(chr((o - 97 + 13) % 26 + 97))
		else:
			out.append(c)
	return "".join(out)


def _voe_decode(raw):
	step = _rot13(raw)
	for junk in ["@$", "^^", "~@", "%?", "*~", "!!", "#&"]:
		step = step.replace(junk, "_")
	step = step.replace("_", "")
	b = base64.b64decode(step)
	shifted = bytes((x - 3) % 256 for x in b)
	rev = shifted[::-1]
	final = base64.b64decode(rev)
	return _json.loads(final)


def resolve_voe(url):
	try:
		r = request("GET", url, headers=_hdr("https://voe.sx/"),
		            timeout=8, retries=0, allow_redirects=True)
		html = r.text
		mred = re.search(r"window\.location\.href\s*=\s*'([^']+)'", html)
		if mred and mred.group(1) not in url:
			r = request("GET", mred.group(1), headers=_hdr("https://voe.sx/"),
			            timeout=8, retries=0, allow_redirects=True)
			html = r.text
		m = re.search(
			r'<script type="application/json"[^>]*>\s*(\[.*?\]|".*?")\s*</script>',
			html, re.S)
		if m:
			raw = _json.loads(m.group(1))
			if isinstance(raw, list):
				raw = raw[0]
			data = _voe_decode(raw)
			src = data.get("source") or data.get("direct_access_url")
			if src:
				origin = "https://%s" % urlparse(r.url).netloc
				return src, _hdr_qs(origin + "/")
		mm = re.search(r"'hls'\s*:\s*'([^']+\.m3u8[^']*)'", html) \
			or re.search(r'"hls"\s*:\s*"([^"]+\.m3u8[^"]*)"', html) \
			or re.search(r"(https?://[^\s'\"<>]+\.m3u8[^\s'\"<>]*)", html)
		if mm:
			cand = mm.group(1)
			if "\\/" in cand:
				cand = cand.replace("\\/", "/")
			origin = "https://%s" % urlparse(r.url).netloc
			return cand, _hdr_qs(origin + "/")
	except Exception:
		log(format_exc())
	return None


def resolve_dood(url):
	try:
		r = request("GET", url, headers=_hdr("https://dood.to/"),
		            timeout=8, retries=0, allow_redirects=True)
		html = r.text
		final_host = "https://%s" % urlparse(r.url).netloc
		embed_ref = r.url
		m = re.search(r"(/pass_md5/[^'\"]+)", html)
		if not m:
			return None
		pass_path = m.group(1)
		tok = re.search(r"token=([a-z0-9]+)", html)
		token = tok.group(1) if tok else pass_path.rsplit("/", 1)[-1]
		pr = request("GET", final_host + pass_path,
		             headers=_hdr(embed_ref), timeout=8, retries=0)
		prefix = pr.text.strip()
		if not prefix.startswith("http"):
			return None
		rand = "".join(_random.choice(_string.ascii_letters + _string.digits)
		               for _ in range(10))
		expiry = int(_time.time() * 1000)
		final = "%s%s?token=%s&expiry=%d" % (prefix, rand, token, expiry)
		return final, _hdr_qs(final_host + "/")
	except Exception:
		log(format_exc())
	return None


_HLS_RE = re.compile(r'https?://[^\s\'"<>]+\.m3u8[^\s\'"<>]*')
_MP4_RE = re.compile(r'https?://[^\s\'"<>]+\.mp4[^\s\'"<>]*')
_ATOB_RE = re.compile(r"atob\(\s*[\"']([A-Za-z0-9+/=_-]{40,})[\"']\s*\)")


def resolve_generic(url, referer=None):
	try:
		r = request("GET", url, headers=_hdr(referer or url),
		            timeout=8, retries=0, allow_redirects=True)
		html = r.text
		origin = "https://%s" % urlparse(r.url).netloc
		for rx in (_HLS_RE, _MP4_RE):
			m = rx.search(html)
			if m:
				return m.group(0).replace("\\/", "/"), _hdr_qs(origin + "/")
		for blob in _ATOB_RE.findall(html):
			try:
				dec = base64.b64decode(blob + "==").decode("utf-8", "ignore")
			except Exception:
				continue
			for rx in (_HLS_RE, _MP4_RE):
				m = rx.search(dec)
				if m:
					return m.group(0), _hdr_qs(origin + "/")
	except Exception:
		log(format_exc())
	return None


def _match(url, hosts):
	low = url.lower()
	return any(h in low for h in hosts)


def resolve(url, referer=None):
	if not url:
		return None
	if _match(url, VOE_HOSTS):
		res = resolve_voe(url)
		if res:
			return res
	if _match(url, DOOD_HOSTS):
		res = resolve_dood(url)
		if res:
			return res
	return resolve_generic(url, referer)
