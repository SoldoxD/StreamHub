
from streamhub.utils import (
	request, log, urlparse, ThreadPoolExecutor, as_completed, format_exc,
)

DEFAULT_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")


def hoster_name(url):
	if not url:
		return "?"
	if url.startswith("dlhd://"):
		return "DLHD"
	try:
		host = urlparse(url).netloc.lower()
	except Exception:
		return "?"
	if "vavoo" in host:
		return "VAVOO"
	if not host:

		return "STALKER"

	host = host.replace("www.", "")
	parts = host.split(".")
	if len(parts) >= 2:
		return ".".join(parts[-2:]).upper()
	return host.upper()


def _check_one(url, timeout=5):
	try:
		if url.startswith("dlhd://"):
			cid = url[len("dlhd://"):]
			probe = "https://dlhd.pk/stream/stream-%s.php" % cid
			r = request("GET", probe,
			            headers={"User-Agent": DEFAULT_UA, "Referer": "https://dlhd.pk/"},
			            timeout=timeout, retries=0, stream=True, allow_redirects=True)
			return r.status_code < 400
		if "vavoo.to" in url:



			return True

		if not urlparse(url).scheme:
			return True
		r = request("HEAD", url, headers={"User-Agent": DEFAULT_UA},
		            timeout=timeout, retries=0, allow_redirects=True)
		if r.status_code in (405, 501):

			r = request("GET", url, headers={"User-Agent": DEFAULT_UA, "Range": "bytes=0-0"},
			            timeout=timeout, retries=0, stream=True, allow_redirects=True)
		return r.status_code < 400
	except Exception:
		log("hoster check failed for %s: %s" % (url, format_exc().splitlines()[-1]))
		return False


def filter_alive(candidates, timeout=5, max_workers=8):
	if not candidates:
		return []
	with ThreadPoolExecutor(max_workers=min(max_workers, len(candidates))) as ex:
		futures = {ex.submit(_check_one, c["url"], timeout): i
		           for i, c in enumerate(candidates)}
		alive = {}
		for fut in as_completed(futures):
			i = futures[fut]
			try:
				alive[i] = fut.result()
			except Exception:
				alive[i] = False
	return [c for i, c in enumerate(candidates) if alive.get(i, False)]


def label_live_streams(urls):
	counts = {}
	out = []
	for u in urls:
		h = hoster_name(u)
		counts[h] = counts.get(h, 0) + 1
	seen = {}
	for u in urls:
		h = hoster_name(u)
		if counts[h] > 1:
			seen[h] = seen.get(h, 0) + 1
			label = "%s #%d" % (h, seen[h])
		else:
			label = h
		out.append({"url": u, "hoster": h, "label": label})
	return out
