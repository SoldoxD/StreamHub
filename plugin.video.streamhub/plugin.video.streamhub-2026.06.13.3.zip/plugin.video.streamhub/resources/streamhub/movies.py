
from streamhub.utils import *

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")


def _ua_headers(referer=None, **extra):
	h = {"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"}
	if referer:
		h["Referer"] = referer
	h.update(extra)
	return h


def _normalize_title(t):
	import re as _re
	t = _re.sub(r"[^\w\s]", " ", t or "")
	t = _re.sub(r"\s+", " ", t).strip().lower()
	return t




class Movies67Provider:
	name = "67movies"
	BASE = "https://67movies.net"






	virtual = True

	def search(self, query, max_results=20):
		return []

	def get_hosts(self, movie):
		tmdb = movie.get("tmdb_id")
		if not tmdb:
			return []


		embed = "https://111movies.net/movie/%s" % tmdb
		return [{
			"provider": self.name,
			"host": "111movies",
			"label": "111movies (TMDB %s)" % tmdb,
			"url": embed,
			"resolver": "embed_generic",
			"referer": "https://67movies.net/",
		}]


class RamoflixProvider:
	name = "ramoflix"
	BASE = "https://ramoflix.net"

	_NON_MOVIE_HINTS = (

		"-season-", "-episode-", "/series/", "/tv-show", "/show/", "/season/",
	)

	_TV_TITLE_HINTS = (
		"andor", "skeleton crew", "bad batch", "mandalorian", "tales of",
		"clone wars", "rebels", "ahsoka", "the acolyte", "obi-wan kenobi",
		"book of boba", "rangers of the new",
	)

	def search(self, query, max_results=20):
		from html import unescape
		try:
			r = request("GET", self.BASE + "/?s=" + quote(query),
			            headers=_ua_headers(self.BASE), timeout=12, retries=0)
			r.raise_for_status()
			html = r.text
		except Exception as e:
			log("ramoflix search failed: %s" % e)
			return []
		out = []
		seen_urls = set()



		card_re = re.compile(
			r'<a[^>]+href="(https?://ramoflix\.net/[^"/]+/)"[^>]*>\s*'
			r'<img[^>]*?(?:data-src="([^"]+)"[^>]*?)?alt="([^"]+)"',
			re.IGNORECASE,
		)
		for m in card_re.finditer(html):
			url = m.group(1)
			poster = m.group(2) or None
			title = unescape(m.group(3)).strip()
			if url in seen_urls:
				continue
			seen_urls.add(url)
			low_url = url.lower()
			if any(h in low_url for h in self._NON_MOVIE_HINTS):
				continue
			if any(h in low_url for h in ("/category/", "/genre/", "/cast/",
			                              "/director/", "/year/")):
				continue
			low_title = title.lower()
			if any(h in low_title for h in self._TV_TITLE_HINTS):
				continue
			out.append({"tmdb_id": None, "title": title, "year": None,
			            "poster": poster,
			            "provider": self.name, "ramoflix_url": url})
			if len(out) >= max_results:
				break
		return out

	def get_hosts(self, movie):
		page = movie.get("ramoflix_url")
		if not page:
			return []
		try:
			r = request("GET", page, headers=_ua_headers(self.BASE),
			            timeout=15, retries=0)
			r.raise_for_status()
			html = r.text
		except Exception as e:
			log("ramoflix page fetch failed: %s" % e)
			return []
		hosts = []


		for prov in ("111movies", "videasy", "vidsrc", "vidwtf",
		             "smashystream", "2embed"):
			if prov in html.lower():

				m = re.search(
					r'(?:src|data-(?:src|link|server))=["\']'
					r'(https?://[^"\']*' + re.escape(prov) + r'[^"\']*)["\']',
					html, re.IGNORECASE)
				if m:
					hosts.append({
						"provider": self.name,
						"host": prov,
						"label": "%s (via ramoflix)" % prov,
						"url": m.group(1),
						"resolver": "embed_generic",
						"referer": page,
					})

		if not hosts:
			for m in re.finditer(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I):
				src = m.group(1)
				if "about:blank" in src or "/ad" in src or "youtube" in src:
					continue
				hosts.append({
					"provider": self.name,
					"host": urlparse(src).netloc or "iframe",
					"label": "%s (via ramoflix)" % (urlparse(src).netloc or "iframe"),
					"url": src,
					"resolver": "embed_generic",
					"referer": page,
				})
		return hosts


class FilmpalastProvider:
	name = "filmpalast"
	BASE = "https://filmpalast.to"
	_TV_SLUG_RE = re.compile(r"-s\d{1,2}e\d{1,2}\b", re.I)

	def search(self, query, max_results=20):
		from html import unescape
		try:

			r = request("GET",
			            self.BASE + "/search/title/" + quote(query),
			            headers=_ua_headers(self.BASE), timeout=12, retries=0)
			r.raise_for_status()
			html = r.text
		except Exception as e:
			log("filmpalast search failed: %s" % e)
			return []
		out = []
		seen = set()

		title_re = re.compile(
			r'<h2[^>]*>\s*<a[^>]+href="(?://)?(?:filmpalast\.to)?(/stream/[^"]+)"'
			r'[^>]*title="([^"]+)"', re.I)
		poster_re = re.compile(
			r'<a[^>]+href="(?://)?(?:filmpalast\.to)?(/stream/[^"]+)"[^>]*>\s*'
			r'<img[^>]+src="([^"]+)"', re.I)
		posters = {p.group(1): p.group(2) for p in poster_re.finditer(html)}
		for m in title_re.finditer(html):
			path = m.group(1)
			title = unescape(m.group(2)).strip()
			if path in seen:
				continue
			seen.add(path)
			if self._TV_SLUG_RE.search(path):
				continue
			poster = posters.get(path)
			if poster and poster.startswith("/"):
				poster = self.BASE + poster
			out.append({"tmdb_id": None, "title": title, "year": None,
			            "poster": poster,
			            "provider": self.name,
			            "filmpalast_url": self.BASE + path})
			if len(out) >= max_results:
				break
		return out

	def get_hosts(self, movie):
		page = movie.get("filmpalast_url")
		if not page:
			return []
		try:
			r = request("GET", page, headers=_ua_headers(self.BASE),
			            timeout=15, retries=0)
			r.raise_for_status()
			html = r.text
		except Exception as e:
			log("filmpalast page fetch failed: %s" % e)
			return []
		hosts = []
		block_re = re.compile(
			r'<ul class="currentStreamLinks">'
			r'.*?<p class="hostName">([^<]+)</p>'
			r'.*?<a[^>]+href="(https?://[^"]+)"',
			re.S | re.I,
		)
		seen_urls = set()
		for m in block_re.finditer(html):
			hoster = m.group(1).strip()
			url = m.group(2).strip()
			if url in seen_urls:
				continue
			seen_urls.add(url)
			hosts.append({
				"provider": self.name,
				"host": urlparse(url).netloc or hoster,
				"label": "%s (via filmpalast)" % hoster,
				"url": url,
				"resolver": "embed_generic",
				"referer": page,
			})
		return hosts


class KinoxProvider:
	name = "kinox"
	BASE = "https://kinox.to"

	def search(self, query, max_results=20):
		from html import unescape
		try:
			r = request("GET",
			            self.BASE + "/Search.html?q=" + quote(query),
			            headers=_ua_headers(self.BASE), timeout=12, retries=0)
			r.raise_for_status()
			html = r.text
		except Exception as e:
			log("kinox search failed: %s" % e)
			return []
		out = []
		seen = set()
		row_re = re.compile(
			r'<a[^>]+href="(/Stream/([^"/]+)\.html)"[^>]*>([^<]+)</a>', re.I)
		for m in row_re.finditer(html):
			path = m.group(1)
			slug = m.group(2)
			text = unescape(m.group(3)).strip()
			if path in seen or not text or text in ("Stream",):
				continue
			seen.add(path)
			title = text if text else slug.replace("_", " ")
			out.append({"tmdb_id": None, "title": title, "year": None,
			            "poster": None,
			            "provider": self.name,
			            "kinox_url": self.BASE + path,
			            "kinox_slug": slug})
			if len(out) >= max_results:
				break
		return out

	def get_hosts(self, movie):
		page = movie.get("kinox_url")
		slug = movie.get("kinox_slug")
		if not page or not slug:
			return []
		try:
			r = request("GET", page, headers=_ua_headers(self.BASE),
			            timeout=15, retries=0)
			r.raise_for_status()
			html = r.text
		except Exception as e:
			log("kinox page fetch failed: %s" % e)
			return []
		hoster_re = re.compile(
			r'<li[^>]+id="Hoster_(\d+)"[^>]+rel="([^"]+)"[^>]*>'
			r'\s*<div class="Named">([^<]+)</div>',
			re.I | re.S,
		)
		hosts = []
		seen_ids = set()
		for hm in hoster_re.finditer(html):
			hid = hm.group(1)
			rel = hm.group(2).replace("&amp;", "&")
			name = hm.group(3).strip()
			if hid in seen_ids:
				continue
			seen_ids.add(hid)
			iframe_url = self._resolve_mirror(rel, page)
			if not iframe_url:
				continue
			hosts.append({
				"provider": self.name,
				"host": name.lower().replace(".", ""),
				"label": "%s (via kinox)" % name,
				"url": iframe_url,
				"resolver": "embed_generic",
				"referer": self.BASE + "/",
			})
		return hosts

	def _resolve_mirror(self, rel, referer):
		try:
			r = request("GET",
			            "%s/aGET/Mirror/%s" % (self.BASE, rel),
			            headers={**_ua_headers(referer),
			                     "X-Requested-With": "XMLHttpRequest"},
			            timeout=12, retries=0)
			r.raise_for_status()
			data = r.json()
		except Exception as e:
			log("kinox mirror %s failed: %s" % (rel, e))
			return None
		stream = data.get("Stream", "")
		m = re.search(r'src=["\']([^"\']+)["\']', stream)
		if not m:
			return None
		src = m.group(1).replace("\\/", "/")
		if src.startswith("/"):
			src = self.BASE + src
		return src


class VavooProvider:
	name = "vavoo"

	def search(self, query, max_results=20):
		from html import unescape
		try:
			from streamhub.vjackson import callApi2


			q = query.replace(".", "%2E")
			res = callApi2("list", {"id": "movie.popular.search=" + q})
			items = res.get("data") if isinstance(res, dict) else res
			if not items:
				return []
		except Exception as e:
			log("vavoo search failed: %s" % e)
			return []
		out = []
		for it in items[:max_results]:
			tid = it.get("id", "")
			tmdb = tid.split(".")[1] if tid.startswith("movie.") and "." in tid else None
			out.append({"tmdb_id": tmdb,
			            "title": unescape(it.get("name", "")),
			            "year": str(it.get("year", "") or ""),
			            "poster": it.get("poster"),
			            "plot": it.get("description"),
			            "provider": self.name,
			            "vavoo_id": tid})
		return out

	def get_hosts(self, movie):
		tmdb = movie.get("tmdb_id")
		if not tmdb:
			return []
		try:
			from streamhub.vjackson import getAuthSignature
			_headers = {
				"user-agent": "MediaHubMX/2",
				"content-type": "application/json; charset=utf-8",
				"accept-encoding": "gzip",
				"mediahubmx-signature": getAuthSignature(),
			}
			_data = {
				"language": "de", "region": "AT", "type": "movie",
				"ids": {"tmdb_id": tmdb}, "name": movie.get("title", ""),
				"episode": {}, "clientVersion": "3.0.2"
			}
			mirrors = request_json(
				"POST", "https://vavoo.to/mediahubmx-source.json",
				json=_data, headers=_headers, timeout=10, retries=1
			) or []
		except Exception as e:
			log("vavoo get_hosts failed: %s" % e)
			return []
		hosts = []
		for a in mirrors:
			url = a.get("url")
			if not url:
				continue
			host = urlparse(url).netloc or "?"
			if "streamz" in host:
				continue
			quality = a.get("tag", "")
			label = "%s%s (vavoo)" % (host, (" " + quality) if quality else "")
			hosts.append({
				"provider": self.name,
				"host": host,
				"label": label,
				"url": url,
				"resolver": "vavoo_chain",
				"quality": quality,
			})
		return hosts


def _enabled_providers():
	provs = []
	if getSetting("vavoo") == "true":
		provs.append(VavooProvider())
	if getSetting("movies67") == "true":
		provs.append(Movies67Provider())
	if getSetting("ramoflix") == "true":
		provs.append(RamoflixProvider())
	if getSetting("filmpalast") == "true":
		provs.append(FilmpalastProvider())
	if getSetting("kinox") == "true":
		provs.append(KinoxProvider())
	return provs




def _merge_results(per_provider):
	by_norm = {}
	merged_order = []
	for provider, results in per_provider:
		for m in results:
			norm = _normalize_title(m.get("title", ""))
			if not norm:
				continue
			entry = by_norm.get(norm)
			if entry is None:
				entry = {
					"title": m.get("title") or "",
					"year": m.get("year"),
					"tmdb_id": m.get("tmdb_id"),
					"poster": m.get("poster"),
					"plot": m.get("plot"),
					"_norm": norm,
					"_hits": [],
				}
				by_norm[norm] = entry
				merged_order.append(entry)

			entry["_hits"].append((provider, m))


			if not entry.get("tmdb_id") and m.get("tmdb_id"):
				entry["tmdb_id"] = m["tmdb_id"]
			if not entry.get("year") and m.get("year"):
				entry["year"] = m["year"]
			if not entry.get("poster") and m.get("poster"):
				entry["poster"] = m["poster"]
			if not entry.get("plot") and m.get("plot"):
				entry["plot"] = m["plot"]

			if len(m.get("title") or "") > len(entry.get("title") or ""):
				entry["title"] = m["title"]
	return merged_order


def search(params):
	cacheOk, history = get_cache("movies_search")
	if not cacheOk:
		history = {}
	kb = xbmc.Keyboard("", "StreamHub - Filme Suche", False)
	kb.doModal()
	if not kb.isConfirmed():
		return
	query = kb.getText().strip()
	if not query:
		return
	history[query] = True
	set_cache("movies_search", history, False)
	_search_and_list(query)


def _search_and_list(query):
	provs = _enabled_providers()
	if not provs:
		dialog.notification("StreamHub", "Keine Quellen aktiviert", time=3000)
		return
	per_provider = []
	with ThreadPoolExecutor(max_workers=max(len(provs), 1)) as ex:
		futs = {ex.submit(p.search, query, 20): p for p in provs}
		for fut in as_completed(futs):
			p = futs[fut]
			try:
				per_provider.append((p.name, fut.result() or []))
			except Exception:
				log(format_exc())
				per_provider.append((p.name, []))
	merged = _merge_results(per_provider)
	if not merged:
		dialog.notification("StreamHub",
		                    "Keine Treffer für: %s" % query, time=3000)
		return
	set_content("movies")
	set_category("Suche: %s" % query)



	prov_objs = _enabled_providers()
	for m in merged:
		providers_hit = {p for p, _ in m["_hits"]}
		for p in prov_objs:
			if getattr(p, "virtual", False) and m.get("tmdb_id"):
				providers_hit.add(p.name)
		providers_sorted = sorted(providers_hit)
		badge = "+".join(p[:1].upper() for p in providers_sorted)
		year_part = " (%s)" % m["year"] if m.get("year") else ""
		label = "%s%s  [COLOR grey](%s)[/COLOR]" % (
			m.get("title", "?"),
			year_part,
			badge,
		)
		o = ListItem(label)
		o.setProperty("IsPlayable", "true")
		if m.get("poster"):
			o.setArt({"poster": m["poster"], "thumb": m["poster"]})
		info_tag = ListItemInfoTag(o, 'video')
		info_year = None
		if m.get("year"):
			y = str(m["year"]).strip()
			if y.isdigit():
				info_year = int(y)
		info_tag.set_info({
			"title": m.get("title", ""),
			"year": info_year,
			"plot": (m.get("plot") or "") +
			        "\n\n[B]Quellen:[/B] " + ", ".join(providers_sorted),
		})
		params = {
			"action": "movie_play",
			"movie": json.dumps({
				"title": m.get("title", ""),
				"year": m.get("year"),
				"tmdb_id": m.get("tmdb_id"),
				"poster": m.get("poster"),
				"plot": m.get("plot"),
				"hits": [{"provider": pn, **mv} for pn, mv in m["_hits"]],
			}),
		}
		add(params, o, False)
	end()


def index(params):
	set_content("files")
	addDir2("Suche (alle Quellen)", "DefaultAddonsSearch", "movie_search")

	provs = _enabled_providers()
	for p in provs:
		if p.name == "vavoo":

			continue
	end()




def _find_provider_hit(provider, movie):
	for hit in movie.get("hits", []):
		if hit.get("provider") == provider.name:
			return hit
	if getattr(provider, "virtual", False):
		if movie.get("tmdb_id"):
			return movie
		return None
	title = movie.get("title", "")
	target = _normalize_title(title)
	cache_key = "phc:%s:%s" % (provider.name, target)
	cached_raw = home.getProperty(cache_key)
	if cached_raw:
		try:
			c = json.loads(cached_raw)
			if not c:
				return None
			return c
		except Exception:
			pass
	try:
		year = movie.get("year")
		results = provider.search(title, max_results=8) or []
	except Exception:
		log(format_exc())
		home.setProperty(cache_key, "null")
		return None
	best = None
	for r in results:
		rt = _normalize_title(r.get("title", ""))
		if rt == target:
			if not year or not r.get("year") or str(r.get("year")) == str(year):
				home.setProperty(cache_key, json.dumps(r))
				return r
			best = best or r
		elif target in rt or rt in target:
			best = best or r
	home.setProperty(cache_key, json.dumps(best or None))
	return best


def _check_host_alive(host, timeout=3):
	url = host.get("url", "")
	if not url:
		return False
	if "vavoo.to" in url or host.get("provider") == "vavoo":
		return True
	try:
		headers = {"User-Agent": UA}
		if host.get("referer"):
			headers["Referer"] = host["referer"]
		r = request("HEAD", url, headers=headers, timeout=timeout,
		            retries=0, allow_redirects=True)
		if r.status_code in (405, 501):
			r = request("GET", url, headers={**headers, "Range": "bytes=0-0"},
			            timeout=timeout, retries=0, stream=True,
			            allow_redirects=True)
		return r.status_code < 400
	except Exception:
		return False


_HOST_SORT = {"vavoo": 0, "filmpalast": 1, "67movies": 2, "ramoflix": 3, "kinox": 4}


def _sortkey(h):
	prov_rank = _HOST_SORT.get(h.get("provider"), 9)
	q = h.get("quality", "") or ""
	q_rank = {"1080p": 0, "FHD": 0, "720p": 1, "HD": 1}.get(q, 2)
	return (prov_rank, q_rank, h.get("label", ""))


def _gather_hosts(movie, manual_dialog=False):
	provs_by_name = {p.name: p for p in _enabled_providers()}
	if not provs_by_name:
		return []
	tasks = []
	seen_providers = set()
	for hit in movie.get("hits", []) or []:
		p = provs_by_name.get(hit.get("provider"))
		if p and p.name not in seen_providers:
			tasks.append((p, hit))
			seen_providers.add(p.name)
	for p in provs_by_name.values():
		if p.name in seen_providers:
			continue
		if getattr(p, "virtual", False) and movie.get("tmdb_id"):
			tasks.append((p, movie))
			seen_providers.add(p.name)
	if not tasks:
		return []
	all_hosts = []
	with ThreadPoolExecutor(max_workers=max(len(tasks), 1)) as ex:
		futs = {ex.submit(p.get_hosts, hit): p.name for p, hit in tasks}
		for fut in as_completed(futs):
			try:
				hs = fut.result() or []
				all_hosts.extend(hs)
			except Exception:
				log(format_exc())
	all_hosts.sort(key=_sortkey)
	return all_hosts


def play(params):
	try:
		movie = json.loads(params.get("movie", "{}"))
	except Exception:
		fail_resolved("Film-Daten ungültig")
		return

	manual = params.get("manual") == "true"
	host_select = getSetting("movies_host_select") == "true" or manual

	cache_key = {"_movie_hosts": movie.get("tmdb_id") or movie.get("title", "")}
	cacheOk, cached_hosts = get_cache(cache_key)
	if cacheOk and isinstance(cached_hosts, list) and cached_hosts:
		all_hosts = cached_hosts
	else:
		all_hosts = _gather_hosts(movie, manual_dialog=host_select)
		if all_hosts:
			set_cache(cache_key, all_hosts, timeout=1)

	if not all_hosts:
		fail_resolved("Keine Hoster gefunden")
		return

	if host_select and len(all_hosts) > 1:
		labels = ["%d. %s" % (i + 1, h.get("label", h.get("host", "?")))
		          for i, h in enumerate(all_hosts)]
		idx = selectDialog(labels, "Hoster wählen — %s" % movie.get("title", ""))
		if idx < 0:
			fail_resolved()
			return
		try_order = [all_hosts[idx]]
	else:
		try_order = all_hosts

	import time as _time
	deadline = _time.time() + 4.0
	for h in try_order:
		if _time.time() > deadline and len(try_order) > 1:
			log("resolve budget exhausted")
			break
		stream = _resolve_host(h)
		if stream:
			_start_playback(movie, h, stream)
			return
		log("host %s failed" % h.get("label", "?"))
	fail_resolved("Stream nicht abrufbar — bitte anderen Hoster wählen")


def _resolve_host(host):
	resolver = host.get("resolver")
	try:
		if resolver == "vavoo_chain":

			from streamhub.vjackson import resolve as vavoo_resolve
			mirror = {"url": host["url"]}
			url = vavoo_resolve(mirror)
			if not url:
				return None
			if "|" in url:
				u, hdr = url.split("|", 1)
				return u, hdr
			return url, None
		if resolver == "embed_generic":
			return _resolve_embed(host)
	except Exception:
		log(format_exc())
	return None




_HLS_RE = re.compile(r'https?://[^\s\'"<>]+\.m3u8[^\s\'"<>]*')
_PACKED_RE = re.compile(r"eval\(function\(p,a,c,k,e,(?:r|d)\)")
_ATOB_RE = re.compile(r"atob\(\s*[\"']([A-Za-z0-9+/=_-]{40,})[\"']\s*\)")


def _resolve_embed(host):
	url = host.get("url", "")
	ref = host.get("referer") or url
	try:
		r = request("GET", url, headers=_ua_headers(ref),
		            timeout=15, retries=0)
		r.raise_for_status()
		html = r.text
	except Exception as e:
		log("embed fetch failed (%s): %s" % (url, e))
		html = ""


	for m in _HLS_RE.finditer(html):
		candidate = m.group(0)

		candidate = candidate.rstrip('"\\)')
		hdr = "Referer=%s&User-Agent=%s" % (quote(ref, safe=""), quote(UA, safe=""))
		return candidate, hdr


	for blob in _ATOB_RE.findall(html):
		try:
			decoded = base64.b64decode(blob + "==").decode("utf-8", "ignore")
		except Exception:
			continue
		mm = _HLS_RE.search(decoded)
		if mm:
			hdr = "Referer=%s&User-Agent=%s" % (quote(ref, safe=""), quote(UA, safe=""))
			return mm.group(0).rstrip('"\\)'), hdr


	try:
		import resolveurl
		resolved = resolveurl.resolve(url)
		if resolved:
			return resolved, None
	except Exception:
		pass

	log("embed %s: no m3u8 found server-side (JS-protected)" % url)
	return None




def _start_playback(movie, host, stream):
	url, headers = stream
	o = ListItem(movie.get("title", "Movie"))
	o.setProperty("IsPlayable", "true")
	if ".m3u8" in url:
		o.setProperty("inputstream", "inputstream.adaptive")
		o.setProperty('inputstream.adaptive.manifest_type', 'hls')
		o.setProperty('inputstream.adaptive.config', '{"ssl_verify_peer":false}')
		if headers:
			o.setProperty('inputstream.adaptive.common_headers', headers)
			o.setProperty('inputstream.adaptive.stream_headers', headers)
	else:
		if headers and "|" not in url:
			url = url + "|" + headers
	o.setPath(url)
	info_tag = ListItemInfoTag(o, 'video')
	info_tag.set_info({
		"title": movie.get("title", ""),
		"plot": "[B]Quelle:[/B] %s\n%s" % (
			host.get("label", "?"), movie.get("title", "")
		),
	})
	play_directly(url, o)
